import fs from 'node:fs';
import path from 'node:path';

const distIndexPath = path.resolve('dist/index.html');
if (!fs.existsSync(distIndexPath)) {
  console.error('dist/index.html not found, run vite build first');
  process.exit(1);
}

let distHtml = fs.readFileSync(distIndexPath, 'utf8');

// 1. Remove the standalone.html redirect script from the compiled HTML so it never loops
distHtml = distHtml.replace(/<script>[\s\S]*?window\.location\.replace\('standalone\.html'\);[\s\S]*?<\/script>/gi, '');

// 2. Remove any old file-protocol-notice from the standalone compiled HTML
distHtml = distHtml.replace(/<div id="file-protocol-notice"[\s\S]*?<\/div>/gi, '');

// 3. Replace <script type="module" crossorigin> or <script type="module"> with standard <script defer>
// This ensures that local file:// opening in any browser (Chrome, Edge, Safari, Firefox)
// will run the script without CORS restrictions or module origin 'null' blocks,
// and 'defer' ensures the DOM is fully parsed before execution.
distHtml = distHtml.replace(/<script\s+type="module"(\s+crossorigin)?>/gi, '<script defer>');

// 4. Write back optimized dist/index.html
fs.writeFileSync(distIndexPath, distHtml, 'utf8');
console.log('✓ dist/index.html updated with deferred standard script');

// 5. Create standalone.html in root for users who double-click and run immediately without Node/Vite
const rootStandalonePath = path.resolve('standalone.html');
fs.writeFileSync(rootStandalonePath, distHtml, 'utf8');
console.log('✓ standalone.html created in root');
