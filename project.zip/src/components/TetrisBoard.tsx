import React, { useRef, useEffect } from 'react';
import type {
  ActivePiece,
  BoardMatrix,
  HardDropTrailData,
  HardDropImpactData,
  LockFlashData,
  GridStyle,
  ColorPalette,
  GhostStyle,
  GhostColor,
  BlockSkin,
} from '../game/types.ts';
import {
  PIECE_SHAPES,
  getPaletteColors,
  VISIBLE_START_ROW,
  GHOST_GRAY_COLOR,
} from '../game/constants.ts';

interface TetrisBoardProps {
  board: BoardMatrix;
  activePiece: ActivePiece | null;
  ghostY: number;
  clearingRows: number[];
  showGhost: boolean;
  ghostStyle?: GhostStyle;
  ghostColor?: GhostColor;
  blockSkin?: BlockSkin;
  ghostOpacity?: number;
  gridOpacity?: number;
  ghostOutline?: boolean;
  showWhiteOutline?: boolean;
  whiteOutlineOpacity?: number;
  softPieceGlow?: boolean;
  matrixShakeEnabled?: boolean;
  impactParticlesEnabled?: boolean;
  lockFlashEnabled?: boolean;
  lineClearEffectsEnabled?: boolean;
  gridStyle?: GridStyle;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  hardDropTrail: HardDropTrailData | null;
  hardDropImpact: HardDropImpactData | null;
  matrixShake?: 'drop' | 'bump-left' | 'bump-right' | null;
  lockFlash: LockFlashData | null;
  isPaused: boolean;
}

export const TetrisBoard: React.FC<TetrisBoardProps> = React.memo(({
  board,
  activePiece,
  ghostY,
  clearingRows,
  showGhost,
  ghostStyle = 'solid',
  ghostColor: ghostColorProp = 'colored',
  gridOpacity = 0.35,
  ghostOutline = true,
  showWhiteOutline = true,
  gridStyle = 'checkerboard',
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  matrixShakeEnabled = true,
  matrixShake,
  lockFlash,
  isPaused,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const palette = getPaletteColors(colorPalette, monochromeColor);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High-DPI Canvas Scaling
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const displayWidth = Math.floor(rect.width) || 250;
    const displayHeight = Math.floor(rect.height) || 500;

    if (canvas.width !== displayWidth * dpr || canvas.height !== displayHeight * dpr) {
      canvas.width = displayWidth * dpr;
      canvas.height = displayHeight * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    const cols = 10;
    const rows = 20;

    // Precise pixel-grid coordinate mapping that guarantees zero bottom/edge gap
    const getCellRect = (c: number, r: number) => {
      const x0 = Math.round((c * displayWidth) / cols);
      const x1 = Math.round(((c + 1) * displayWidth) / cols);
      const y0 = Math.round((r * displayHeight) / rows);
      const y1 = Math.round(((r + 1) * displayHeight) / rows);
      return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
    };

    // 1. Clear background
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, displayWidth, displayHeight);

    // 2. Render Grid / Checkerboard pattern with working opacity
    const gridAlpha = Math.max(0, Math.min(1, gridOpacity ?? 0.35));
    if (gridStyle === 'checkerboard') {
      const checkFill = `rgba(255, 255, 255, ${(gridAlpha * 0.12).toFixed(3)})`;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if ((r + c) % 2 === 0) {
            const { x, y, width: w, height: h } = getCellRect(c, r);
            ctx.fillStyle = checkFill;
            ctx.fillRect(x, y, w, h);
          }
        }
      }
    } else if (gridStyle === 'grid') {
      ctx.strokeStyle = `rgba(255, 255, 255, ${(gridAlpha * 0.28).toFixed(3)})`;
      ctx.lineWidth = 1;
      for (let c = 1; c < cols; c++) {
        const x = Math.round((c * displayWidth) / cols);
        ctx.beginPath();
        ctx.moveTo(x + 0.5, 0);
        ctx.lineTo(x + 0.5, displayHeight);
        ctx.stroke();
      }
      for (let r = 1; r < rows; r++) {
        const y = Math.round((r * displayHeight) / rows);
        ctx.beginPath();
        ctx.moveTo(0, y + 0.5);
        ctx.lineTo(displayWidth, y + 0.5);
        ctx.stroke();
      }
    }

    // 3. Render Locked Board Minos (Flat solid fill, no bevels)
    for (let r = 0; r < rows; r++) {
      const actualRow = VISIBLE_START_ROW + r;
      const rowData = board[actualRow];
      if (!rowData) continue;

      const isClearing = clearingRows.includes(actualRow);

      for (let c = 0; c < cols; c++) {
        const type = rowData[c];
        if (!type) continue;

        const { x, y, width: w, height: h } = getCellRect(c, r);

        if (isClearing) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(x, y, w, h);
        } else {
          const colorDef = palette[type];
          ctx.fillStyle = colorDef ? colorDef.solid : '#94a3b8';
          ctx.fillRect(x, y, w, h);
        }
      }
    }

    // 4. White Stack Silhouette Outline (if enabled)
    if (showWhiteOutline) {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      for (let r = 0; r < rows; r++) {
        const actualRow = VISIBLE_START_ROW + r;
        for (let c = 0; c < cols; c++) {
          if (board[actualRow]?.[c] !== null) {
            const { x, y, width: w, height: h } = getCellRect(c, r);
            // Top edge
            if (actualRow > 0 && board[actualRow - 1]?.[c] === null) {
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(x + w, y);
              ctx.stroke();
            }
            // Bottom edge (only if inside board and block below is empty)
            if (actualRow < 39 && board[actualRow + 1]?.[c] === null) {
              ctx.beginPath();
              ctx.moveTo(x, y + h);
              ctx.lineTo(x + w, y + h);
              ctx.stroke();
            }
            // Left edge
            if (c === 0 || board[actualRow]?.[c - 1] === null) {
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(x, y + h);
              ctx.stroke();
            }
            // Right edge
            if (c === cols - 1 || board[actualRow]?.[c + 1] === null) {
              ctx.beginPath();
              ctx.moveTo(x + w, y);
              ctx.lineTo(x + w, y + h);
              ctx.stroke();
            }
          }
        }
      }
    }

    // 5. Render Ghost Piece (silhouette on Canvas)
    if (showGhost && activePiece && !isPaused) {
      const gColor =
        ghostColorProp === 'gray'
          ? GHOST_GRAY_COLOR
          : palette[activePiece.type]?.solid || '#38bdf8';

      const shape = PIECE_SHAPES[activePiece.type][activePiece.rotation];
      const isConnected = ghostStyle === 'solid' || (ghostStyle as string) === 'connected';

      ctx.save();

      // In connected mode, first clear the underlying grid pattern so the ghost looks like one solid, unified piece
      if (isConnected) {
        ctx.fillStyle = '#09090b';
        ctx.globalAlpha = 1.0;
        for (let r = 0; r < shape.length; r++) {
          for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c] !== 0) {
              const bx = activePiece.x + c;
              const by = ghostY - VISIBLE_START_ROW + r;
              if (by >= 0 && by < rows && bx >= 0 && bx < cols) {
                const { x, y, width: w, height: h } = getCellRect(bx, by);
                ctx.fillRect(x, y, w, h);
              }
            }
          }
        }
      }

      // Fill color tint
      ctx.globalAlpha = isConnected ? 0.32 : 0.28;
      ctx.fillStyle = gColor;

      for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
          if (shape[r][c] !== 0) {
            const bx = activePiece.x + c;
            const by = ghostY - VISIBLE_START_ROW + r;
            if (by >= 0 && by < rows && bx >= 0 && bx < cols) {
              const { x, y, width: w, height: h } = getCellRect(bx, by);
              ctx.fillRect(x, y, w, h);
            }
          }
        }
      }

      // Silhouette contour outline (Connected / solid vs Blocks / separated)
      if (ghostOutline) {
        ctx.globalAlpha = 0.85;
        ctx.strokeStyle = gColor;
        ctx.lineWidth = 1.5;
        ctx.lineCap = 'square';
        ctx.lineJoin = 'miter';

        if (isConnected) {
          // Connected solid silhouette: trace ONLY the outer perimeter of the tetromino
          ctx.beginPath();
          for (let r = 0; r < shape.length; r++) {
            for (let c = 0; c < shape[r].length; c++) {
              if (shape[r][c] !== 0) {
                const bx = activePiece.x + c;
                const by = ghostY - VISIBLE_START_ROW + r;
                if (by >= 0 && by < rows && bx >= 0 && bx < cols) {
                  const { x, y, width: w, height: h } = getCellRect(bx, by);

                  // Top edge: only if no tetromino block above
                  if (r === 0 || shape[r - 1]?.[c] === 0) {
                    ctx.moveTo(x, y + 0.5);
                    ctx.lineTo(x + w, y + 0.5);
                  }

                  // Bottom edge: only if no tetromino block below
                  if (r === shape.length - 1 || shape[r + 1]?.[c] === 0) {
                    ctx.moveTo(x, y + h - 0.5);
                    ctx.lineTo(x + w, y + h - 0.5);
                  }

                  // Left edge: only if no tetromino block to the left
                  if (c === 0 || shape[r]?.[c - 1] === 0) {
                    ctx.moveTo(x + 0.5, y);
                    ctx.lineTo(x + 0.5, y + h);
                  }

                  // Right edge: only if no tetromino block to the right
                  if (c === shape[r].length - 1 || shape[r]?.[c + 1] === 0) {
                    ctx.moveTo(x + w - 0.5, y);
                    ctx.lineTo(x + w - 0.5, y + h);
                  }
                }
              }
            }
          }
          ctx.stroke();
        } else {
          // Separated / blocks: outline each individual block
          for (let r = 0; r < shape.length; r++) {
            for (let c = 0; c < shape[r].length; c++) {
              if (shape[r][c] !== 0) {
                const bx = activePiece.x + c;
                const by = ghostY - VISIBLE_START_ROW + r;
                if (by >= 0 && by < rows && bx >= 0 && bx < cols) {
                  const { x, y, width: w, height: h } = getCellRect(bx, by);
                  ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
                }
              }
            }
          }
        }
      }
      ctx.restore();
    }

    // 6. Render Current Active Piece (Flat solid fill, no bevels)
    if (activePiece && !isPaused) {
      const pColor = palette[activePiece.type]?.solid || '#38bdf8';
      const shape = PIECE_SHAPES[activePiece.type][activePiece.rotation];

      for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
          if (shape[r][c] !== 0) {
            const bx = activePiece.x + c;
            const by = activePiece.y - VISIBLE_START_ROW + r;

            if (by >= 0 && by < rows && bx >= 0 && bx < cols) {
              const { x, y, width: w, height: h } = getCellRect(bx, by);
              ctx.fillStyle = pColor;
              ctx.fillRect(x, y, w, h);
            }
          }
        }
      }
    }

    // 7. Lock Flash Animation
    if (lockFlash && !isPaused) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      for (const pt of lockFlash.cells) {
        const vr = pt.y - VISIBLE_START_ROW;
        if (vr >= 0 && vr < rows && pt.x >= 0 && pt.x < cols) {
          const { x, y, width: w, height: h } = getCellRect(pt.x, vr);
          ctx.fillRect(x, y, w, h);
        }
      }
    }

    // 8. Paused State Overlay
    if (isPaused) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillRect(0, 0, displayWidth, displayHeight);

      ctx.fillStyle = '#e4e4e7';
      ctx.font = 'bold 18px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('PAUSED', displayWidth / 2, displayHeight / 2 - 8);

      ctx.font = '10px monospace';
      ctx.fillStyle = '#71717a';
      ctx.fillText('Press Pause to Resume', displayWidth / 2, displayHeight / 2 + 14);
    }

    ctx.restore();
  }, [
    board,
    activePiece,
    ghostY,
    clearingRows,
    showGhost,
    ghostStyle,
    ghostColorProp,
    gridOpacity,
    ghostOutline,
    showWhiteOutline,
    gridStyle,
    colorPalette,
    monochromeColor,
    palette,
    lockFlash,
    isPaused,
  ]);

  const shakeClass =
    !matrixShakeEnabled
      ? ''
      : matrixShake === 'drop'
      ? 'animate-matrix-dip'
      : matrixShake === 'bump-left'
      ? 'animate-matrix-bump-left'
      : matrixShake === 'bump-right'
      ? 'animate-matrix-bump-right'
      : '';

  return (
    <div
      ref={containerRef}
      className={`relative rounded-b-sm overflow-hidden border-l-2 border-r-2 border-b-2 border-t-0 border-white/90 shadow-2xl bg-zinc-950 flex items-center justify-center ${shakeClass}`}
      style={{
        borderTop: 'none',
        borderTopWidth: 0,
        borderTopStyle: 'none',
        borderTopColor: 'transparent',
      }}
    >
      <canvas
        ref={canvasRef}
        className="block select-none"
        style={{
          width: 'clamp(200px, 48vh, 250px)',
          aspectRatio: '10/20',
          imageRendering: 'pixelated',
        }}
      />
    </div>
  );
});

TetrisBoard.displayName = 'TetrisBoard';
