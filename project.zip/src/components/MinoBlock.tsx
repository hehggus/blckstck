import React from 'react';
import type { PieceType, GridStyle, ColorPalette, BlockSkin } from '../game/types.ts';
import { getPaletteColors, GRAYSCALE_COLORS, type PieceColorDef } from '../game/constants.ts';

interface MinoBlockProps {
  type: PieceType | null;
  isGhost?: boolean;
  isClearing?: boolean;
  isGrayscale?: boolean;
  isLocked?: boolean;
  row?: number;
  col?: number;
  gridStyle?: GridStyle;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  customPalette?: Record<PieceType, PieceColorDef>;
  blockSkin?: BlockSkin;
  hasBottomNeighbor?: boolean;
  hasRightNeighbor?: boolean;
  hasBottomRightNeighbor?: boolean;
  size?: number | string;
}

export const MinoBlock: React.FC<MinoBlockProps> = React.memo(({
  type,
  isGhost = false,
  isClearing = false,
  isGrayscale = false,
  row = 0,
  col = 0,
  gridStyle = 'checkerboard',
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  customPalette,
  size = '100%',
}) => {
  // Empty Cell
  if (!type && !isClearing) {
    if (gridStyle === 'grid') {
      return (
        <div
          className="w-full h-full select-none"
          style={{
            width: size,
            height: size,
            border: '1px solid rgba(255, 255, 255, 0.15)',
          }}
        />
      );
    }
    const isLightSquare = (row + col) % 2 === 0;
    return (
      <div
        className="w-full h-full select-none"
        style={{
          width: size,
          height: size,
          backgroundColor: isLightSquare ? 'rgba(255, 255, 255, 0.05)' : 'transparent',
        }}
      />
    );
  }

  // Row clearing flash
  if (isClearing) {
    return (
      <div
        className="w-full h-full select-none pointer-events-none relative"
        style={{
          width: size,
          height: size,
          backgroundColor: '#ffffff',
        }}
      />
    );
  }

  const palette = customPalette || getPaletteColors(colorPalette, monochromeColor);
  const colors = isGrayscale ? GRAYSCALE_COLORS : (type ? palette[type] : GRAYSCALE_COLORS);

  // Ghost piece: 30% alpha flat solid fill
  if (isGhost) {
    return (
      <div
        className="w-full h-full select-none"
        style={{
          width: size,
          height: size,
          backgroundColor: colors.solid,
          opacity: 0.3,
        }}
      />
    );
  }

  // Clean flat solid fill piece without bevels or insets
  return (
    <div
      className="w-full h-full select-none"
      style={{
        width: size || '100%',
        height: size || '100%',
        backgroundColor: colors.solid,
      }}
    />
  );
});

MinoBlock.displayName = 'MinoBlock';
