import React from 'react';
import type { GameMode, GameStats, Language } from '../game/types.ts';
import { formatTime } from '../game/rules.ts';
import { TRANSLATIONS } from '../game/i18n.ts';

interface StatsPanelProps {
  stats: GameStats;
  mode: GameMode;
  language?: Language;
}

export const StatsPanel: React.FC<StatsPanelProps> = React.memo(({ stats, mode, language = 'en' }) => {
  const t = TRANSLATIONS[language];
  const timerText =
    mode === 'ultra' && stats.remainingTime !== undefined
      ? formatTime(stats.remainingTime)
      : formatTime(stats.timeElapsed);

  return (
    <div className="flex flex-col items-center select-none w-14 sm:w-16 text-center font-mono mt-4 space-y-2.5 flex-shrink-0 tabular-nums">
      {/* SCORE */}
      <div className="flex flex-col items-center w-full">
        <span className="text-[9px] sm:text-[10px] font-medium tracking-wider text-zinc-500 uppercase">
          {t.score}
        </span>
        <span className="text-xs sm:text-[13px] font-bold text-zinc-100 tracking-tight leading-none mt-0.5 truncate w-full">
          {stats.score.toLocaleString()}
        </span>
      </div>

      {/* LEVEL */}
      <div className="flex flex-col items-center w-full">
        <span className="text-[9px] sm:text-[10px] font-medium tracking-wider text-zinc-500 uppercase">
          {t.level}
        </span>
        <span className="text-xs sm:text-[13px] font-bold text-zinc-200 tracking-tight leading-none mt-0.5">
          {stats.level}
        </span>
      </div>

      {/* LINES */}
      <div className="flex flex-col items-center w-full">
        <span className="text-[9px] sm:text-[10px] font-medium tracking-wider text-zinc-500 uppercase">
          {t.lines}
        </span>
        <span className="text-xs sm:text-[13px] font-bold text-zinc-200 tracking-tight leading-none mt-0.5">
          {stats.lines}
        </span>
      </div>

      {/* PIECES */}
      <div className="flex flex-col items-center w-full">
        <span className="text-[9px] sm:text-[10px] font-medium tracking-wider text-zinc-500 uppercase">
          {t.pieces}
        </span>
        <span className="text-xs sm:text-[13px] font-bold text-zinc-300 tracking-tight leading-none mt-0.5">
          {stats.pieces}
        </span>
      </div>

      {/* TIME */}
      <div className="flex flex-col items-center pt-1.5 border-t border-white/[0.08] w-full">
        <span className="text-[8px] sm:text-[9px] font-medium tracking-wider text-zinc-500 uppercase">
          {t.time}
        </span>
        <span className="text-[10px] sm:text-xs font-bold text-zinc-300 tracking-tight font-mono mt-0.5">
          {timerText}
        </span>
      </div>
    </div>
  );
});

StatsPanel.displayName = 'StatsPanel';
