import React from 'react';
import type { PieceType, ColorPalette, BlockSkin } from '../game/types.ts';
import { PIECE_SHAPES } from '../game/constants.ts';
import { MinoBlock } from './MinoBlock.tsx';

interface HoldQueueProps {
  piece: PieceType | null;
  canHold: boolean;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  blockSkin?: BlockSkin;
}

export const HoldQueue: React.FC<HoldQueueProps> = React.memo(({
  piece,
  canHold,
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  blockSkin = 'solid',
}) => {
  const shape = piece ? PIECE_SHAPES[piece][0] : null;

  return (
    <div className="flex flex-col items-center select-none w-14 sm:w-16 flex-shrink-0">
      {/* Label: Strictly aligned with NEXT */}
      <span className="h-5 flex items-center justify-center text-[10px] sm:text-[11px] font-semibold font-mono tracking-wider text-zinc-400 uppercase mb-2">
        HOLD
      </span>

      {/* Piece container: strictly matching first NEXT slot dimensions without any transition flicker */}
      <div className="w-14 sm:w-16 h-11 sm:h-12 flex items-center justify-center">
        {shape && piece ? (
          <div
            className={`grid gap-0 ${!canHold ? 'opacity-40 grayscale' : 'opacity-100'}`}
            style={{
              gridTemplateColumns: `repeat(${shape[0].length}, minmax(0, 1fr))`,
            }}
          >
            {shape.map((row, rIdx) =>
              row.map((cell, cIdx) => (
                <div
                  key={`hold-cell-${rIdx}-${cIdx}`}
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4"
                >
                  {cell !== 0 ? (
                    <MinoBlock
                      type={piece}
                      isGrayscale={!canHold}
                      colorPalette={colorPalette}
                      monochromeColor={monochromeColor}
                      blockSkin={blockSkin}
                      hasBottomNeighbor={rIdx < shape.length - 1 && shape[rIdx + 1][cIdx] !== 0}
                      hasRightNeighbor={cIdx < row.length - 1 && shape[rIdx][cIdx + 1] !== 0}
                      hasBottomRightNeighbor={rIdx < shape.length - 1 && cIdx < row.length - 1 && shape[rIdx + 1][cIdx + 1] !== 0}
                      row={rIdx}
                      col={cIdx}
                    />
                  ) : (
                    <div className="w-full h-full" />
                  )}
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="w-10 h-8" />
        )}
      </div>
    </div>
  );
});

HoldQueue.displayName = 'HoldQueue';
