import React from 'react';
import type { PieceType, ColorPalette, BlockSkin } from '../game/types.ts';
import { PIECE_SHAPES } from '../game/constants.ts';
import { MinoBlock } from './MinoBlock.tsx';

interface NextQueueProps {
  queue: PieceType[];
  count?: number;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  blockSkin?: BlockSkin;
}

export const NextQueue: React.FC<NextQueueProps> = React.memo(({
  queue,
  count = 5,
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  blockSkin = 'solid',
}) => {
  const displayPieces = queue.slice(0, count);

  return (
    <div className="flex flex-col items-center select-none w-14 sm:w-16 flex-shrink-0">
      {/* Label: Strictly aligned with HOLD */}
      <span className="h-5 flex items-center justify-center text-[10px] sm:text-[11px] font-semibold font-mono tracking-wider text-zinc-400 uppercase mb-2">
        NEXT
      </span>

      {/* Queue items: stable slot keys to prevent unmounting/remounting flicker */}
      <div className="flex flex-col gap-3 sm:gap-3.5 items-center w-full">
        {Array.from({ length: count }).map((_, slotIdx) => {
          const type = displayPieces[slotIdx];
          const shape = type ? PIECE_SHAPES[type][0] : null;

          return (
            <div
              key={`next-slot-${slotIdx}`}
              className="w-14 sm:w-16 h-11 sm:h-12 flex items-center justify-center"
            >
              {shape && type ? (
                <div
                  className="grid gap-0"
                  style={{
                    gridTemplateColumns: `repeat(${shape[0].length}, minmax(0, 1fr))`,
                  }}
                >
                  {shape.map((row, rIdx) =>
                    row.map((cell, cIdx) => (
                      <div
                        key={`cell-${slotIdx}-${rIdx}-${cIdx}`}
                        className="w-3.5 h-3.5 sm:w-4 sm:h-4"
                      >
                        {cell !== 0 ? (
                          <MinoBlock
                            type={type}
                            colorPalette={colorPalette}
                            monochromeColor={monochromeColor}
                            blockSkin={blockSkin}
                            hasBottomNeighbor={rIdx < shape.length - 1 && shape[rIdx + 1][cIdx] !== 0}
                            hasRightNeighbor={cIdx < row.length - 1 && shape[rIdx][cIdx + 1] !== 0}
                            hasBottomRightNeighbor={rIdx < shape.length - 1 && cIdx < row.length - 1 && shape[rIdx + 1][cIdx + 1] !== 0}
                            row={rIdx}
                            col={cIdx}
                          />
                        ) : (
                          <div className="w-full h-full" />
                        )}
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="w-10 h-8" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
});

NextQueue.displayName = 'NextQueue';
