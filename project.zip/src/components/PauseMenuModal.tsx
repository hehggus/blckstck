import React, { useState, useEffect } from 'react';
import type { GameMode, GameSettings, GridStyle, ColorPalette, GhostStyle, GhostColor } from '../game/types.ts';
import { COLOR_PALETTES, createMonochromePalette } from '../game/constants.ts';
import { TRANSLATIONS, MONOCHROME_PRESETS } from '../game/i18n.ts';
import {
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  Music,
  X,
  Grid,
  Sliders,
  Eye,
  Flame,
  Zap,
  Clock,
  Sparkles,
} from 'lucide-react';
import { LevelStepper } from './LevelStepper.tsx';

interface PauseMenuModalProps {
  isOpen: boolean;
  onResume: () => void;
  onRestart: () => void;
  mode: GameMode;
  onSelectMode: (mode: GameMode, startLevel: number) => void;
  startLevel: number;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
}

export const PauseMenuModal: React.FC<PauseMenuModalProps> = ({
  isOpen,
  onResume,
  onRestart,
  mode,
  onSelectMode,
  startLevel,
  settings,
  onUpdateSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'modes' | 'settings'>('modes');
  // Marathon starting level chosen in this menu (Guideline Section 6)
  const [pendingLevel, setPendingLevel] = useState(startLevel);
  const lang = settings.language || 'en';
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (isOpen) {
      setActiveTab('modes');
      setPendingLevel(startLevel);
    }
  }, [isOpen, startLevel]);

  if (!isOpen) return null;

  const modes: { id: GameMode; name: string; desc: string; icon: any }[] = [
    {
      id: 'marathon',
      name: t.modes.marathon.name,
      desc: t.modes.marathon.desc,
      icon: Flame,
    },
    {
      id: 'sprint',
      name: t.modes.sprint.name,
      desc: t.modes.sprint.desc,
      icon: Zap,
    },
    {
      id: 'ultra',
      name: t.modes.ultra.name,
      desc: t.modes.ultra.desc,
      icon: Clock,
    },
    {
      id: 'freeplay',
      name: t.modes.freeplay.name,
      desc: t.modes.freeplay.desc,
      icon: Sparkles,
    },
  ];

  const palettes: { id: ColorPalette; name: string }[] = [
    { id: 'pastel_neon', name: t.palettes.pastel_neon },
    { id: 'vivid_guideline', name: t.palettes.vivid_guideline },
    { id: 'monochrome_gray', name: t.palettes.monochrome_gray },
  ];

  const gridStyles: { id: GridStyle; name: string }[] = [
    { id: 'checkerboard', name: t.gridStyles.checkerboard },
    { id: 'grid', name: t.gridStyles.grid },
  ];

  const currentGhostStyle: GhostStyle =
    settings.ghostStyle === 'separated' || (settings.ghostStyle as string) === 'cells'
      ? 'separated'
      : 'solid';

  const currentGhostColor: GhostColor =
    settings.ghostColor === 'gray' ? 'gray' : 'colored';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      {/* Sleek Minimalist Modal Container with crisp smaller corner radius */}
      <div className="bg-[#18181c] border border-zinc-700/60 rounded-lg w-full max-w-sm p-3.5 sm:p-4 shadow-2xl text-zinc-200 font-sans max-h-[92vh] flex flex-col">
        {/* Header with Title and Language Toggle */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/[0.06] flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-zinc-400" />
            <h2 className="text-sm font-bold font-mono tracking-wider text-zinc-100 uppercase">
              {t.paused}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onResume}
              aria-label={t.resume}
              className="w-7 h-7 rounded-md bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] flex items-center justify-center text-zinc-400 hover:text-white transition-all active:scale-95 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 2 Tabs: MODES and SETTINGS */}
        <div className="grid grid-cols-2 gap-1 p-0.5 bg-white/[0.03] rounded-md border border-white/[0.06] mb-2.5 flex-shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('modes')}
            className={`py-1.5 rounded text-xs font-mono font-medium tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'modes'
                ? 'bg-white text-zinc-950 font-bold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {t.tabMode}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`py-1.5 rounded text-xs font-mono font-medium tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-white text-zinc-950 font-bold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {t.settings}
          </button>
        </div>

        {/* Scrollable Content Area */}
        <div className="space-y-2.5 overflow-y-auto flex-1 pr-1">
          {/* TAB 1: MODES */}
          {activeTab === 'modes' && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between px-1">
                <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                  {t.chooseMode}
                </span>
              </div>
              <div className="space-y-1.5">
                {modes.map((m) => {
                  const isSelected = mode === m.id;
                  const Icon = m.icon;
                  return (
                    <div
                      key={m.id}
                      className={`w-full p-2.5 rounded-md border transition-all flex items-center gap-2 ${
                        isSelected
                          ? 'bg-white/[0.08] border-white/30 text-white'
                          : 'bg-white/[0.02] border-white/[0.05] hover:bg-white/[0.05] text-zinc-300 hover:text-white'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onSelectMode(m.id, pendingLevel)}
                        className="flex-1 min-w-0 flex items-center justify-between gap-2 text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`w-7 h-7 rounded flex items-center justify-center flex-shrink-0 ${
                              isSelected
                                ? 'bg-white text-zinc-950'
                                : 'bg-white/[0.04] text-zinc-400'
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <span className="font-mono font-bold text-xs block truncate">
                              {m.name}
                            </span>
                            <span className="text-[10px] text-zinc-400 block truncate">
                              {m.desc}
                            </span>
                          </div>
                        </div>
                        {isSelected && (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 flex-shrink-0" />
                        )}
                      </button>
                      {m.id === 'marathon' && (
                        <LevelStepper
                          level={pendingLevel}
                          onChange={setPendingLevel}
                          label={t.level}
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-2.5 text-xs">
              {/* --- VISUAL EFFECTS --- */}
              <div className="bg-white/[0.02] p-2.5 rounded-md border border-white/[0.06] space-y-2.5">
                <div className="flex items-center gap-1.5 border-b border-white/[0.04] pb-1">
                  <Eye className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    {t.visualEffects}
                  </span>
                </div>

                {/* Screen Shake */}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.matrixShake}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ matrixShakeEnabled: !settings.matrixShakeEnabled })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      settings.matrixShakeEnabled
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        settings.matrixShakeEnabled ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Impact FX */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.impactParticles}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ impactParticlesEnabled: !settings.impactParticlesEnabled })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      settings.impactParticlesEnabled
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        settings.impactParticlesEnabled ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Lock Flash */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.lockFlash}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ lockFlashEnabled: !(settings.lockFlashEnabled ?? true) })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      (settings.lockFlashEnabled ?? true)
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        (settings.lockFlashEnabled ?? true) ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Line Clear FX */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.lineClearFx}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        lineClearEffectsEnabled: !(settings.lineClearEffectsEnabled ?? true),
                      })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      (settings.lineClearEffectsEnabled ?? true)
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        (settings.lineClearEffectsEnabled ?? true)
                          ? 'bg-zinc-950'
                          : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Action Text */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.actionText}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ actionTextEnabled: !(settings.actionTextEnabled ?? true) })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      (settings.actionTextEnabled ?? true)
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        (settings.actionTextEnabled ?? true) ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* --- BOARD & BLOCKS --- */}
              <div className="bg-white/[0.02] p-2.5 rounded-md border border-white/[0.06] space-y-2.5">
                <div className="flex items-center gap-1.5 border-b border-white/[0.04] pb-1">
                  <Sparkles className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    {t.boardBlocks}
                  </span>
                </div>

                {/* Block Skin */}
                <div className="pt-1.5 border-t border-white/[0.04] space-y-1">
                  <span className="text-xs text-zinc-300">{t.blockSkin}</span>
                  <div className="grid grid-cols-2 gap-1">
                    <button
                      type="button"
                      onClick={() => onUpdateSettings({ blockSkin: 'solid' })}
                      className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                        (settings.blockSkin || 'solid') === 'solid'
                          ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                          : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                      }`}
                    >
                      {t.blockSkins.solid}
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateSettings({ blockSkin: 'lines' })}
                      className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                        settings.blockSkin === 'lines'
                          ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                          : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                      }`}
                    >
                      {t.blockSkins.lines}
                    </button>
                  </div>
                </div>

                {/* Color Palettes */}
                <div className="pt-1.5 border-t border-white/[0.04] space-y-1">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-zinc-400" />
                    <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                      {t.palette}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {palettes.map((p) => {
                      const isSelected = (settings.colorPalette || 'vivid_guideline') === p.id;
                      const sampleColors =
                        p.id === 'monochrome_gray'
                          ? createMonochromePalette(settings.monochromeColor || '#94a3b8')
                          : COLOR_PALETTES[p.id];

                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => onUpdateSettings({ colorPalette: p.id })}
                          className={`w-full py-2 px-2.5 rounded-md border text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-white/[0.08] border-white/25 text-white'
                              : 'bg-white/[0.02] border-white/[0.04] hover:bg-white/[0.05] text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-xs">
                              {p.name}
                            </span>
                            <div className="flex items-center gap-1">
                              {(['I', 'J', 'L', 'O', 'S', 'T', 'Z'] as const).map((mino) => (
                                <span
                                  key={mino}
                                  className="w-2.5 h-2.5 rounded-sm"
                                  style={{ backgroundColor: sampleColors[mino].solid }}
                                />
                              ))}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Unified Monochrome Color Spectrum Picker */}
                  {settings.colorPalette === 'monochrome_gray' && (
                    <div className="p-2 bg-white/[0.02] rounded-md border border-white/[0.06] space-y-2 mt-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-mono text-zinc-300 font-semibold">
                          {t.monochromeColor}
                        </span>
                        <span className="text-[10px] font-mono text-zinc-400">
                          {t.monochromeColors[settings.monochromeColor || '#94a3b8'] ||
                            settings.monochromeColor}
                        </span>
                      </div>
                      <div className="grid grid-cols-6 gap-1.5 pt-0.5">
                        {MONOCHROME_PRESETS.map((p) => {
                          const isColorSelected =
                            (settings.monochromeColor || '#94a3b8').toLowerCase() ===
                            p.hex.toLowerCase();
                          return (
                            <button
                              key={p.hex}
                              type="button"
                              title={p.enName}
                              onClick={() => onUpdateSettings({ monochromeColor: p.hex })}
                              className={`h-7 rounded flex items-center justify-center transition-all cursor-pointer border ${
                                isColorSelected
                                  ? 'border-white scale-110 shadow-[0_0_8px_rgba(255,255,255,0.5)] z-10'
                                  : 'border-white/10 hover:border-white/40'
                              }`}
                              style={{ backgroundColor: p.hex }}
                            >
                              {isColorSelected && (
                                <span className="w-1.5 h-1.5 rounded-full bg-black/80" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Grid Style & Opacity */}
                <div className="pt-1.5 border-t border-white/[0.04] space-y-2">
                  <div className="flex items-center gap-1.5">
                    <Grid className="w-3 h-3 text-zinc-400" />
                    <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                      {t.gridStyle}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1">
                    {gridStyles.map((g) => {
                      const isSelected = settings.gridStyle === g.id;
                      return (
                        <button
                          key={g.id}
                          type="button"
                          onClick={() => onUpdateSettings({ gridStyle: g.id })}
                          className={`py-1.5 px-1 rounded-md border text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                              : 'bg-white/[0.02] border-white/[0.04] text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          <span className="block text-[11px] font-mono">
                            {g.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Grid Opacity Slider */}
                  <div className="pt-1">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-xs text-zinc-300">{t.gridOpacity}</span>
                      <span className="font-mono text-zinc-300 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                        {Math.round((settings.gridOpacity ?? 0.35) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.00"
                      max="0.80"
                      step="0.05"
                      value={settings.gridOpacity ?? 0.35}
                      onChange={(e) =>
                        onUpdateSettings({ gridOpacity: Number(e.target.value) })
                      }
                      className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* --- GUIDES & OUTLINES --- */}
              <div className="bg-white/[0.02] p-2.5 rounded-md border border-white/[0.06] space-y-2.5">
                <div className="flex items-center gap-1.5 border-b border-white/[0.04] pb-1">
                  <Eye className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    {t.guidesOutlines}
                  </span>
                </div>

                {/* Ghost Piece Toggle & Sub-options */}
                <div className="pt-1.5 border-t border-white/[0.04] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-200 font-medium">{t.ghostPiece}</span>
                    <button
                      type="button"
                      onClick={() => onUpdateSettings({ ghostPiece: !settings.ghostPiece })}
                      className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                        settings.ghostPiece
                          ? 'bg-zinc-200 justify-end'
                          : 'bg-zinc-800 justify-start'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full ${
                          settings.ghostPiece ? 'bg-zinc-950' : 'bg-zinc-400'
                        }`}
                      />
                    </button>
                  </div>

                  {settings.ghostPiece && (
                    <div className="space-y-2 pt-0.5">
                      {/* Ghost Color buttons */}
                      <div className="space-y-1">
                        <span className="text-xs text-zinc-300">{t.ghostColor}</span>
                        <div className="grid grid-cols-2 gap-1">
                          <button
                            type="button"
                            onClick={() => onUpdateSettings({ ghostColor: 'colored' })}
                            className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                              currentGhostColor === 'colored'
                                ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                                : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                            }`}
                          >
                            {t.ghostColors.colored}
                          </button>
                          <button
                            type="button"
                            onClick={() => onUpdateSettings({ ghostColor: 'gray' })}
                            className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                              currentGhostColor === 'gray'
                                ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                                : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                            }`}
                          >
                            {t.ghostColors.gray}
                          </button>
                        </div>
                      </div>

                      {/* Ghost Style buttons */}
                      <div className="space-y-1">
                        <span className="text-xs text-zinc-300">{t.ghostStyle}</span>
                        <div className="grid grid-cols-2 gap-1">
                          <button
                            type="button"
                            onClick={() => onUpdateSettings({ ghostStyle: 'solid' })}
                            className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                              currentGhostStyle === 'solid'
                                ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                                : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                            }`}
                          >
                            {t.ghostStyles.solid}
                          </button>
                          <button
                            type="button"
                            onClick={() => onUpdateSettings({ ghostStyle: 'separated' })}
                            className={`py-1 px-2 rounded-md border text-xs font-mono font-medium transition-all cursor-pointer ${
                              currentGhostStyle === 'separated'
                                ? 'bg-white/[0.08] border-white/25 text-white font-bold'
                                : 'bg-white/[0.02] border-white/[0.05] text-zinc-400 hover:text-white'
                            }`}
                          >
                            {t.ghostStyles.separated}
                          </button>
                        </div>
                      </div>

                      {/* Ghost Outline Toggle */}
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-xs text-zinc-300">{t.ghostOutline}</span>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateSettings({ ghostOutline: !(settings.ghostOutline ?? true) })
                          }
                          className={`w-8 h-4 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                            (settings.ghostOutline ?? true)
                              ? 'bg-zinc-200 justify-end'
                              : 'bg-zinc-800 justify-start'
                          }`}
                        >
                          <div
                            className={`w-3 h-3 rounded-full ${
                              (settings.ghostOutline ?? true) ? 'bg-zinc-950' : 'bg-zinc-400'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Ghost Opacity Slider */}
                      <div>
                        <div className="flex justify-between items-center mb-0.5">
                          <span className="text-xs text-zinc-300">{t.ghostOpacity}</span>
                          <span className="font-mono text-zinc-300 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                            {Math.round(Math.min(0.50, settings.ghostOpacity ?? 0.05) * 100)}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0.05"
                          max="0.50"
                          step="0.05"
                          value={Math.min(0.50, settings.ghostOpacity ?? 0.05)}
                          onChange={(e) =>
                            onUpdateSettings({ ghostOpacity: Number(e.target.value) })
                          }
                          className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* White Outline */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.whiteOutline}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ showWhiteOutline: !settings.showWhiteOutline })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      settings.showWhiteOutline
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        settings.showWhiteOutline ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* White Outline Opacity */}
                <div
                  className={`pt-1 pl-1 transition-opacity ${
                    settings.showWhiteOutline ? '' : 'opacity-40 pointer-events-none'
                  }`}
                >
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-xs text-zinc-300">{t.whiteOutlineOpacity}</span>
                    <span className="font-mono text-zinc-300 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                      {Math.round((settings.whiteOutlineOpacity ?? 1) * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.whiteOutlineOpacity ?? 1}
                    onChange={(e) =>
                      onUpdateSettings({ whiteOutlineOpacity: Number(e.target.value) })
                    }
                    className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                  />
                </div>

                {/* Soft Glow */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-xs text-zinc-200 font-medium">{t.softPieceGlow}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ softPieceGlow: !(settings.softPieceGlow ?? true) })
                    }
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      (settings.softPieceGlow ?? true)
                        ? 'bg-zinc-200 justify-end'
                        : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        (settings.softPieceGlow ?? true) ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* --- SECTION 2: HANDLING (DAS, ARR, SDF) --- */}
              <div className="bg-white/[0.02] p-2.5 rounded-md border border-white/[0.06] space-y-2.5">
                <div className="flex items-center gap-1.5 border-b border-white/[0.04] pb-1">
                  <Sliders className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    {t.tabHandling}
                  </span>
                </div>

                {/* DAS */}
                <div>
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-xs font-medium text-zinc-200">{t.das}</span>
                    <span className="font-mono text-zinc-200 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                      {settings.das} ms
                    </span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="300"
                    step="5"
                    value={settings.das}
                    onChange={(e) => onUpdateSettings({ das: Number(e.target.value) })}
                    className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                  />
                </div>

                {/* ARR */}
                <div className="pt-1.5 border-t border-white/[0.04]">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-xs font-medium text-zinc-200">{t.arr}</span>
                    <span className="font-mono text-zinc-200 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                      {settings.arr === 0
                        ? '0 ms (instant)'
                        : `${settings.arr} ms`}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="50"
                    step="2"
                    value={settings.arr}
                    onChange={(e) => onUpdateSettings({ arr: Number(e.target.value) })}
                    className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                  />
                </div>

                {/* SDF */}
                <div className="pt-1.5 border-t border-white/[0.04]">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-xs font-medium text-zinc-200">{t.sdf}</span>
                    <span className="font-mono text-zinc-200 font-semibold text-xs bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
                      {settings.sdf}x
                    </span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="40"
                    step="5"
                    value={settings.sdf}
                    onChange={(e) => onUpdateSettings({ sdf: Number(e.target.value) })}
                    className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer mt-1"
                  />
                </div>
              </div>

              {/* --- SECTION 3: AUDIO --- */}
              <div className="bg-white/[0.02] p-2.5 rounded-md border border-white/[0.06] space-y-2">
                <div className="flex items-center gap-1.5 border-b border-white/[0.04] pb-1">
                  <Volume2 className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    {t.tabAudio}
                  </span>
                </div>

                {/* SFX Toggle */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {settings.soundEnabled ? (
                      <Volume2 className="w-3.5 h-3.5 text-zinc-300" />
                    ) : (
                      <VolumeX className="w-3.5 h-3.5 text-zinc-500" />
                    )}
                    <span className="text-xs text-zinc-200 font-medium">{t.soundFx}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      settings.soundEnabled ? 'bg-zinc-200 justify-end' : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        settings.soundEnabled ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* SFX Volume */}
                {settings.soundEnabled && (
                  <div className="pt-1">
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={settings.soundVolume}
                      onChange={(e) => onUpdateSettings({ soundVolume: Number(e.target.value) })}
                      className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer"
                    />
                  </div>
                )}

                {/* Music Toggle */}
                <div className="pt-1.5 border-t border-white/[0.04] flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Music className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="text-xs text-zinc-200 font-medium">{t.music}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ musicEnabled: !settings.musicEnabled })}
                    className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center cursor-pointer ${
                      settings.musicEnabled ? 'bg-zinc-200 justify-end' : 'bg-zinc-800 justify-start'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full ${
                        settings.musicEnabled ? 'bg-zinc-950' : 'bg-zinc-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Music Volume */}
                {settings.musicEnabled && (
                  <div className="pt-1">
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={settings.musicVolume}
                      onChange={(e) => onUpdateSettings({ musicVolume: Number(e.target.value) })}
                      className="w-full accent-white h-1 bg-zinc-800 rounded appearance-none cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Actions: Resume & Restart */}
        <div className="pt-2.5 mt-2 border-t border-white/[0.06] grid grid-cols-2 gap-1.5 flex-shrink-0">
          <button
            type="button"
            onClick={onResume}
            className="w-full py-2 px-3 rounded-md bg-white hover:bg-zinc-200 active:scale-[0.98] text-zinc-950 font-mono font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {t.resume}
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="w-full py-2 px-3 rounded-md bg-white/[0.04] hover:bg-white/[0.08] active:scale-[0.98] border border-white/[0.08] text-zinc-300 hover:text-white font-mono font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {t.restart}
          </button>
        </div>
      </div>
    </div>
  );
};
