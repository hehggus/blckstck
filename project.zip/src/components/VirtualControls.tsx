import React, { useRef, useEffect } from 'react';
import type { GameSettings } from '../game/types.ts';
import { soundManager } from '../utils/audio.ts';

interface VirtualControlsProps {
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onSoftDrop: () => void;
  onHardDrop: () => void;
  onRotateCW: () => void;
  onRotateCCW: () => void;
  onRotate180: () => void;
  onHold: () => void;
  onResetWallBump?: () => void;
  settings: GameSettings;
  activeColor?: string;
  activeGlow?: string;
  softGlowEnabled?: boolean;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  onMoveLeft,
  onMoveRight,
  onSoftDrop,
  onHardDrop,
  onRotateCW,
  onRotateCCW,
  onRotate180,
  onHold,
  onResetWallBump,
  settings,
  activeColor = '#38bdf8',
  activeGlow = 'rgba(56, 189, 248, 0.6)',
  softGlowEnabled = true,
}) => {
  const actionsRef = useRef({
    onMoveLeft,
    onMoveRight,
    onSoftDrop,
    onHardDrop,
    onRotateCW,
    onRotateCCW,
    onRotate180,
    onHold,
    onResetWallBump,
    settings,
  });

  useEffect(() => {
    actionsRef.current = {
      onMoveLeft,
      onMoveRight,
      onSoftDrop,
      onHardDrop,
      onRotateCW,
      onRotateCCW,
      onRotate180,
      onHold,
      onResetWallBump,
      settings,
    };
  }, [
    onMoveLeft,
    onMoveRight,
    onSoftDrop,
    onHardDrop,
    onRotateCW,
    onRotateCCW,
    onRotate180,
    onHold,
    onResetWallBump,
    settings,
  ]);

  // Touch tracking references
  const touchStateRef = useRef<{
    activeDir: 'left' | 'right' | null;
    pointerId: number | null;
    dasTimer: any;
    arrTimer: any;
    softDropPointerId: number | null;
    softDropTimer: any;
  }>({
    activeDir: null,
    pointerId: null,
    dasTimer: null,
    arrTimer: null,
    softDropPointerId: null,
    softDropTimer: null,
  });

  const clearHorizTimers = () => {
    if (touchStateRef.current.dasTimer) {
      clearTimeout(touchStateRef.current.dasTimer);
      touchStateRef.current.dasTimer = null;
    }
    if (touchStateRef.current.arrTimer) {
      clearInterval(touchStateRef.current.arrTimer);
      touchStateRef.current.arrTimer = null;
    }
  };

  const stopSoftDrop = (pointerId?: number) => {
    if (
      pointerId !== undefined &&
      touchStateRef.current.softDropPointerId !== pointerId &&
      touchStateRef.current.softDropPointerId !== null
    ) {
      return;
    }
    if (touchStateRef.current.softDropTimer) {
      clearInterval(touchStateRef.current.softDropTimer);
      touchStateRef.current.softDropTimer = null;
    }
    touchStateRef.current.softDropPointerId = null;
  };

  const handleHorizDown = (dir: 'left' | 'right', e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch (_) {}

    clearHorizTimers();
    actionsRef.current.onResetWallBump?.();

    touchStateRef.current.activeDir = dir;
    touchStateRef.current.pointerId = e.pointerId;

    if (dir === 'left') {
      actionsRef.current.onMoveLeft();
    } else {
      actionsRef.current.onMoveRight();
    }

    const dasMs = actionsRef.current.settings.das || 133;
    const arrMs = actionsRef.current.settings.arr || 10;

    touchStateRef.current.dasTimer = setTimeout(() => {
      if (arrMs === 0) {
        touchStateRef.current.arrTimer = setInterval(() => {
          for (let i = 0; i < 10; i++) {
            if (dir === 'left') actionsRef.current.onMoveLeft();
            else actionsRef.current.onMoveRight();
          }
        }, 16);
      } else {
        touchStateRef.current.arrTimer = setInterval(() => {
          if (dir === 'left') actionsRef.current.onMoveLeft();
          else actionsRef.current.onMoveRight();
        }, arrMs);
      }
    }, dasMs);
  };

  const handleHorizUp = (pointerId: number, e?: React.PointerEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (touchStateRef.current.pointerId === pointerId) {
      clearHorizTimers();
      touchStateRef.current.activeDir = null;
      touchStateRef.current.pointerId = null;
      actionsRef.current.onResetWallBump?.();
    }
  };

  const handleSoftDropDown = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch (_) {}

    stopSoftDrop();
    touchStateRef.current.softDropPointerId = e.pointerId;
    actionsRef.current.onSoftDrop();

    const sdf = actionsRef.current.settings.sdf || 20;
    const intervalMs = sdf >= 40 ? 25 : 38;
    touchStateRef.current.softDropTimer = setInterval(() => {
      actionsRef.current.onSoftDrop();
    }, intervalMs);
  };

  const handleInstantAction = (action: () => void, e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();
    action();
  };

  useEffect(() => {
    const handleGlobalPointerUp = (e: PointerEvent) => {
      handleHorizUp(e.pointerId);
      stopSoftDrop(e.pointerId);
    };
    window.addEventListener('pointerup', handleGlobalPointerUp);
    window.addEventListener('pointercancel', handleGlobalPointerUp);
    return () => {
      window.removeEventListener('pointerup', handleGlobalPointerUp);
      window.removeEventListener('pointercancel', handleGlobalPointerUp);
      clearHorizTimers();
      stopSoftDrop();
    };
  }, []);

  const btnClass =
    'relative group w-full min-h-[48px] sm:min-h-[56px] aspect-square rounded-md bg-white/[0.04] hover:bg-white/[0.08] active:scale-[0.93] text-zinc-300 active:text-white flex items-center justify-center transition-all select-none touch-none cursor-pointer border border-white/[0.08] outline-none shadow-sm overflow-hidden';

  const SparkleOverlay = () => (
    <div
      className="absolute inset-0 rounded-md pointer-events-none opacity-0 group-active:opacity-100 transition-opacity duration-75 z-0"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        boxShadow: softGlowEnabled
          ? `inset 0 0 10px ${activeColor}50, 0 0 12px ${activeGlow}`
          : 'none',
        borderColor: `${activeColor}aa`,
        borderWidth: '1.5px',
        borderStyle: 'solid',
      }}
    />
  );

  return (
    <div
      className="w-full max-w-[460px] mx-auto px-1 sm:px-2 select-none touch-none mt-2 sm:mt-3 pb-1"
      style={{ touchAction: 'none' }}
    >
      <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
        {/* ROW 1: 2 blank slots, then 180° Rotate, Hold, Hard Drop */}
        <div className="w-full aspect-square pointer-events-none" />
        <div className="w-full aspect-square pointer-events-none" />

        {/* 180° Rotate */}
        <button
          type="button"
          aria-label="Rotate 180 degrees"
          className={btnClass}
          onPointerDown={(e) => handleInstantAction(actionsRef.current.onRotate180, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
              <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
              <path d="M21 21v-5h-5" />
            </svg>
          </div>
        </button>

        {/* Hold Button */}
        <button
          type="button"
          aria-label="Hold piece"
          className={btnClass}
          onPointerDown={(e) => handleInstantAction(actionsRef.current.onHold, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 8h16" />
              <path d="M15 4l5 4-5 4" />
              <path d="M20 16H4" />
              <path d="M9 12l-5 4 5 4" />
            </svg>
          </div>
        </button>

        {/* Hard Drop Button */}
        <button
          type="button"
          aria-label="Hard drop"
          className={btnClass}
          onPointerDown={(e) => handleInstantAction(actionsRef.current.onHardDrop, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6 text-zinc-200"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 7l6 6 6-6" />
              <path d="M6 13l6 6 6-6" />
            </svg>
          </div>
        </button>

        {/* ROW 2: Move Left, Move Right, Soft Drop, Rotate CCW, Rotate CW */}
        {/* Move Left */}
        <button
          type="button"
          aria-label="Move left"
          className={btnClass}
          onPointerDown={(e) => handleHorizDown('left', e)}
          onPointerUp={(e) => handleHorizUp(e.pointerId, e)}
          onPointerCancel={(e) => handleHorizUp(e.pointerId, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </div>
        </button>

        {/* Move Right */}
        <button
          type="button"
          aria-label="Move right"
          className={btnClass}
          onPointerDown={(e) => handleHorizDown('right', e)}
          onPointerUp={(e) => handleHorizUp(e.pointerId, e)}
          onPointerCancel={(e) => handleHorizUp(e.pointerId, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M9 6l6 6-6 6" />
            </svg>
          </div>
        </button>

        {/* Soft Drop */}
        <button
          type="button"
          aria-label="Soft drop"
          className={btnClass}
          onPointerDown={handleSoftDropDown}
          onPointerUp={(e) => stopSoftDrop(e.pointerId)}
          onPointerCancel={(e) => stopSoftDrop(e.pointerId)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 9l6 6 6-6" />
            </svg>
          </div>
        </button>

        {/* Rotate CCW */}
        <button
          type="button"
          aria-label="Rotate counter-clockwise"
          className={btnClass}
          onPointerDown={(e) => handleInstantAction(actionsRef.current.onRotateCCW, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </div>
        </button>

        {/* Rotate CW */}
        <button
          type="button"
          aria-label="Rotate clockwise"
          className={btnClass}
          onPointerDown={(e) => handleInstantAction(actionsRef.current.onRotateCW, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12a9 9 0 1 1-9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
              <path d="M21 3v5h-5" />
            </svg>
          </div>
        </button>
      </div>
    </div>
  );
};
