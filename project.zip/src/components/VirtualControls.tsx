import React, { useRef, useEffect } from 'react';
import type { GameSettings } from '../game/types.ts';
import { soundManager } from '../utils/audio.ts';

interface VirtualControlsProps {
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onMoveLeftStart?: () => void;
  onMoveLeftEnd?: () => void;
  onMoveRightStart?: () => void;
  onMoveRightEnd?: () => void;
  onSoftDrop: () => void;
  onSoftDropStart?: () => void;
  onSoftDropEnd?: () => void;
  onHardDrop: () => void;
  onRotateCW: () => void;
  onRotateCCW: () => void;
  onRotate180: () => void;
  onHold: () => void;
  onResetWallBump?: () => void;
  settings: GameSettings;
  activeColor?: string;
  activeGlow?: string;
  softGlowEnabled?: boolean;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  onMoveLeft,
  onMoveRight,
  onMoveLeftStart,
  onMoveLeftEnd,
  onMoveRightStart,
  onMoveRightEnd,
  onSoftDrop,
  onSoftDropStart,
  onSoftDropEnd,
  onHardDrop,
  onRotateCW,
  onRotateCCW,
  onRotate180,
  onHold,
  activeColor = '#38bdf8',
  activeGlow = 'rgba(56, 189, 248, 0.6)',
  softGlowEnabled = true,
}) => {
  const actionsRef = useRef({
    onMoveLeft,
    onMoveRight,
    onMoveLeftStart,
    onMoveLeftEnd,
    onMoveRightStart,
    onMoveRightEnd,
    onSoftDrop,
    onSoftDropStart,
    onSoftDropEnd,
    onHardDrop,
    onRotateCW,
    onRotateCCW,
    onRotate180,
    onHold,
  });

  useEffect(() => {
    actionsRef.current = {
      onMoveLeft,
      onMoveRight,
      onMoveLeftStart,
      onMoveLeftEnd,
      onMoveRightStart,
      onMoveRightEnd,
      onSoftDrop,
      onSoftDropStart,
      onSoftDropEnd,
      onHardDrop,
      onRotateCW,
      onRotateCCW,
      onRotate180,
      onHold,
    };
  });

  // Touch Event Handlers with mandatory e.preventDefault() to eradicate 300ms delay & zoom
  const handleTouchAction = (action: () => void, e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) {
      e.preventDefault();
    }
    e.stopPropagation();
    soundManager.initContext();
    action();
  };

  const handleLeftStart = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();
    if (actionsRef.current.onMoveLeftStart) {
      actionsRef.current.onMoveLeftStart();
    } else {
      actionsRef.current.onMoveLeft();
    }
  };

  const handleLeftEnd = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    if (actionsRef.current.onMoveLeftEnd) {
      actionsRef.current.onMoveLeftEnd();
    }
  };

  const handleRightStart = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();
    if (actionsRef.current.onMoveRightStart) {
      actionsRef.current.onMoveRightStart();
    } else {
      actionsRef.current.onMoveRight();
    }
  };

  const handleRightEnd = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    if (actionsRef.current.onMoveRightEnd) {
      actionsRef.current.onMoveRightEnd();
    }
  };

  const handleSoftDropStart = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    soundManager.initContext();
    if (actionsRef.current.onSoftDropStart) {
      actionsRef.current.onSoftDropStart();
    } else {
      actionsRef.current.onSoftDrop();
    }
  };

  const handleSoftDropEnd = (e: React.TouchEvent | React.MouseEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    if (actionsRef.current.onSoftDropEnd) {
      actionsRef.current.onSoftDropEnd();
    }
  };

  const btnClass =
    'relative group w-full min-h-[48px] sm:min-h-[56px] aspect-square rounded-md bg-white/[0.04] hover:bg-white/[0.08] active:scale-[0.93] text-zinc-300 active:text-white flex items-center justify-center transition-all select-none touch-none cursor-pointer border border-white/[0.08] outline-none shadow-sm overflow-hidden';

  const SparkleOverlay = () => (
    <div
      className="absolute inset-0 rounded-md pointer-events-none opacity-0 group-active:opacity-100 transition-opacity duration-75 z-0"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        boxShadow: softGlowEnabled
          ? `inset 0 0 10px ${activeColor}50, 0 0 12px ${activeGlow}`
          : 'none',
        borderColor: `${activeColor}aa`,
        borderWidth: '1.5px',
        borderStyle: 'solid',
      }}
    />
  );

  return (
    <div
      className="w-full max-w-[460px] mx-auto px-1 sm:px-2 select-none touch-none mt-2 sm:mt-3 pb-1"
      style={{ touchAction: 'none', userSelect: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
        {/* ROW 1: 2 blanks, Rotate 180, Hold, Hard Drop */}
        <div className="w-full aspect-square pointer-events-none" />
        <div className="w-full aspect-square pointer-events-none" />

        {/* 180° Rotate */}
        <button
          type="button"
          aria-label="Rotate 180 degrees"
          className={btnClass}
          onTouchStart={(e) => handleTouchAction(actionsRef.current.onRotate180, e)}
          onTouchEnd={(e) => { if (e.cancelable) e.preventDefault(); }}
          onMouseDown={(e) => handleTouchAction(actionsRef.current.onRotate180, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
              <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
              <path d="M21 21v-5h-5" />
            </svg>
          </div>
        </button>

        {/* Hold Button */}
        <button
          type="button"
          aria-label="Hold piece"
          className={btnClass}
          onTouchStart={(e) => handleTouchAction(actionsRef.current.onHold, e)}
          onTouchEnd={(e) => { if (e.cancelable) e.preventDefault(); }}
          onMouseDown={(e) => handleTouchAction(actionsRef.current.onHold, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 8h16" />
              <path d="M15 4l5 4-5 4" />
              <path d="M20 16H4" />
              <path d="M9 12l-5 4 5 4" />
            </svg>
          </div>
        </button>

        {/* Hard Drop Button */}
        <button
          type="button"
          aria-label="Hard drop"
          className={btnClass}
          onTouchStart={(e) => handleTouchAction(actionsRef.current.onHardDrop, e)}
          onTouchEnd={(e) => { if (e.cancelable) e.preventDefault(); }}
          onMouseDown={(e) => handleTouchAction(actionsRef.current.onHardDrop, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6 text-zinc-200"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 7l6 6 6-6" />
              <path d="M6 13l6 6 6-6" />
            </svg>
          </div>
        </button>

        {/* ROW 2: Move Left, Move Right, Soft Drop, Rotate CCW, Rotate CW */}
        {/* Move Left */}
        <button
          type="button"
          aria-label="Move left"
          className={btnClass}
          onTouchStart={handleLeftStart}
          onTouchEnd={handleLeftEnd}
          onTouchCancel={handleLeftEnd}
          onMouseDown={handleLeftStart}
          onMouseUp={handleLeftEnd}
          onMouseLeave={handleLeftEnd}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </div>
        </button>

        {/* Move Right */}
        <button
          type="button"
          aria-label="Move right"
          className={btnClass}
          onTouchStart={handleRightStart}
          onTouchEnd={handleRightEnd}
          onTouchCancel={handleRightEnd}
          onMouseDown={handleRightStart}
          onMouseUp={handleRightEnd}
          onMouseLeave={handleRightEnd}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M9 6l6 6-6 6" />
            </svg>
          </div>
        </button>

        {/* Soft Drop */}
        <button
          type="button"
          aria-label="Soft drop"
          className={btnClass}
          onTouchStart={handleSoftDropStart}
          onTouchEnd={handleSoftDropEnd}
          onTouchCancel={handleSoftDropEnd}
          onMouseDown={handleSoftDropStart}
          onMouseUp={handleSoftDropEnd}
          onMouseLeave={handleSoftDropEnd}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 9l6 6 6-6" />
            </svg>
          </div>
        </button>

        {/* Rotate CCW */}
        <button
          type="button"
          aria-label="Rotate counter-clockwise"
          className={btnClass}
          onTouchStart={(e) => handleTouchAction(actionsRef.current.onRotateCCW, e)}
          onTouchEnd={(e) => { if (e.cancelable) e.preventDefault(); }}
          onMouseDown={(e) => handleTouchAction(actionsRef.current.onRotateCCW, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </div>
        </button>

        {/* Rotate CW */}
        <button
          type="button"
          aria-label="Rotate clockwise"
          className={btnClass}
          onTouchStart={(e) => handleTouchAction(actionsRef.current.onRotateCW, e)}
          onTouchEnd={(e) => { if (e.cancelable) e.preventDefault(); }}
          onMouseDown={(e) => handleTouchAction(actionsRef.current.onRotateCW, e)}
        >
          <SparkleOverlay />
          <div className="relative z-10 flex items-center justify-center">
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12a9 9 0 1 1-9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
              <path d="M21 3v5h-5" />
            </svg>
          </div>
        </button>
      </div>
    </div>
  );
};
