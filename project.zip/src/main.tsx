import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function init() {
  const rootEl = document.getElementById('root');
  if (rootEl && !(window as any).__TETRIS_MOUNTED__) {
    (window as any).__TETRIS_MOUNTED__ = true;
    createRoot(rootEl).render(<App />);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
