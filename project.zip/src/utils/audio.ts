// High-Performance Web Audio API Sound Manager with Pre-Cached AudioBuffers
// Designed for zero-latency audio playback in Android WebView (Capacitor)

class SoundManager {
  private ctx: AudioContext | null = null;
  private soundVolume = 0.5;
  private musicVolume = 0.3;
  private soundEnabled = true;
  private musicEnabled = false;
  private isMusicPlaying = false;
  private musicInterval: any = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private lastSoftDropTime = 0;

  // Pre-rendered, cached PCM AudioBuffers for zero input-lag SFX
  private bufferCache = new Map<string, AudioBuffer>();
  private isPreloaded = false;

  constructor() {
    // Automatically register user gesture listeners to wake & unlock AudioContext
    if (typeof window !== 'undefined') {
      const unlockAudio = () => {
        this.initContext();
        window.removeEventListener('touchstart', unlockAudio);
        window.removeEventListener('touchend', unlockAudio);
        window.removeEventListener('mousedown', unlockAudio);
        window.removeEventListener('keydown', unlockAudio);
      };
      window.addEventListener('touchstart', unlockAudio, { passive: true });
      window.addEventListener('touchend', unlockAudio, { passive: true });
      window.addEventListener('mousedown', unlockAudio, { passive: true });
      window.addEventListener('keydown', unlockAudio, { passive: true });
    }
  }

  public initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx({ sampleRate: 44100 });
        this.sfxGainNode = this.ctx.createGain();
        this.sfxGainNode.gain.setValueAtTime(this.soundVolume, this.ctx.currentTime);
        this.sfxGainNode.connect(this.ctx.destination);
      }
    }

    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      if (!this.isPreloaded) {
        this.preloadAllBuffers();
      }
    }
  }

  // Pre-synthesize and decode all audio effects into in-memory AudioBuffers
  private preloadAllBuffers() {
    if (!this.ctx || this.isPreloaded) return;
    this.isPreloaded = true;
    const sampleRate = this.ctx.sampleRate;

    // Helper: generate synthetic AudioBuffer with custom sample generator
    const createBuffer = (duration: number, gen: (t: number, i: number, total: number) => number): AudioBuffer => {
      const length = Math.floor(sampleRate * duration);
      const buffer = this.ctx!.createBuffer(1, length, sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) {
        const t = i / sampleRate;
        data[i] = gen(t, i, length);
      }
      return buffer;
    };

    // 1. Move Sound: Quick crisp triangle blip (440Hz -> 880Hz, 30ms)
    this.bufferCache.set('move', createBuffer(0.035, (t) => {
      const freq = 440 + (880 - 440) * (t / 0.035);
      const phase = 2 * Math.PI * freq * t;
      const wave = (2 / Math.PI) * Math.asin(Math.sin(phase)); // triangle
      const envelope = Math.max(0, 1 - t / 0.035);
      return wave * envelope * 0.45;
    }));

    // 2. Rotate Sound: Smooth sine pitch jump (520Hz -> 780Hz, 45ms)
    this.bufferCache.set('rotate', createBuffer(0.045, (t) => {
      const freq = 520 + (780 - 520) * (t / 0.045);
      const wave = Math.sin(2 * Math.PI * freq * t);
      const envelope = Math.max(0, 1 - t / 0.045);
      return wave * envelope * 0.55;
    }));

    // 3. Rotate 180 Sound: Dual-pulse punchy square chirp (392Hz -> 880Hz, 65ms)
    this.bufferCache.set('rotate180', createBuffer(0.065, (t) => {
      const freq = 392 + (880 - 392) * (t / 0.065);
      const wave = Math.sin(2 * Math.PI * freq * t) >= 0 ? 0.6 : -0.6; // soft square
      const envelope = Math.max(0, 1 - t / 0.065);
      return wave * envelope * 0.45;
    }));

    // 4. Soft Drop Sound: Deep downward step (260Hz -> 180Hz, 25ms)
    this.bufferCache.set('softDrop', createBuffer(0.025, (t) => {
      const freq = 260 - (260 - 180) * (t / 0.025);
      const wave = Math.sin(2 * Math.PI * freq * t);
      const envelope = Math.max(0, 1 - t / 0.025);
      return wave * envelope * 0.35;
    }));

    // 5. Hard Drop Sound: Heavy bass boom + crisp mechanical impact transient (120ms)
    this.bufferCache.set('hardDrop', createBuffer(0.12, (t, i) => {
      // Bass sine sweep
      const freq = Math.max(35, 180 * Math.exp(-t * 22));
      const bass = Math.sin(2 * Math.PI * freq * t) * Math.exp(-t * 18);
      // Click snap (noise burst in first 15ms)
      const noise = (t < 0.018) ? (Math.sin(i * 1234.567) % 1) * (1 - t / 0.018) * 0.45 : 0;
      return (bass * 0.8 + noise) * 0.85;
    }));

    // 6. Lock Sound: Solid thud (280Hz -> 140Hz, 55ms)
    this.bufferCache.set('lock', createBuffer(0.055, (t) => {
      const freq = 280 - (280 - 140) * (t / 0.055);
      const wave = Math.sin(2 * Math.PI * freq * t);
      const envelope = Math.exp(-t * 35);
      return wave * envelope * 0.6;
    }));

    // 7. Hold Sound: Pleasant two-tone chime (C5 + E5)
    this.bufferCache.set('hold', createBuffer(0.12, (t) => {
      const w1 = Math.sin(2 * Math.PI * 523.25 * t) * Math.exp(-t * 20);
      const w2 = (t > 0.035) ? Math.sin(2 * Math.PI * 659.25 * (t - 0.035)) * Math.exp(-(t - 0.035) * 18) : 0;
      return (w1 * 0.5 + w2 * 0.5) * 0.65;
    }));

    // 8. T-Spin Sound: Futuristic resonant sweep (330Hz -> 880Hz, 180ms)
    this.bufferCache.set('tspin', createBuffer(0.18, (t) => {
      const freq = 330 + (880 - 330) * Math.pow(t / 0.18, 1.5);
      const sq = Math.sin(2 * Math.PI * freq * t) >= 0 ? 0.7 : -0.7;
      const sin = Math.sin(2 * Math.PI * freq * 2 * t);
      const envelope = Math.max(0, 1 - t / 0.18);
      return (sq * 0.5 + sin * 0.5) * envelope * 0.6;
    }));

    // 9. Line Clear Sounds (1, 2, 3, 4 lines)
    const clearNotes = [
      [523.25, 659.25],                        // 1 line
      [523.25, 659.25, 783.99],                 // 2 lines
      [523.25, 659.25, 783.99, 1046.50],        // 3 lines
      [523.25, 659.25, 783.99, 1046.50, 1318.51] // 4 lines (Tetris)
    ];

    clearNotes.forEach((notes, linesIdx) => {
      const duration = linesIdx === 3 ? 0.38 : 0.18;
      this.bufferCache.set(`clear_${linesIdx + 1}`, createBuffer(duration, (t) => {
        let sample = 0;
        notes.forEach((freq, idx) => {
          const noteStart = idx * 0.032;
          if (t >= noteStart) {
            const relT = t - noteStart;
            const env = Math.exp(-relT * (linesIdx === 3 ? 8 : 16));
            const wave = (linesIdx === 3)
              ? (2 / Math.PI) * Math.atan(Math.tan(Math.PI * freq * relT)) // sawtooth
              : (2 / Math.PI) * Math.asin(Math.sin(2 * Math.PI * freq * relT)); // triangle
            sample += wave * env * 0.35;
          }
        });
        return sample;
      }));
    });

    // 10. Level Up Sound: Ascending 4-tone fanfare
    this.bufferCache.set('levelup', createBuffer(0.35, (t) => {
      const freqs = [440, 554.37, 659.25, 880];
      let sample = 0;
      freqs.forEach((f, idx) => {
        const start = idx * 0.07;
        if (t >= start) {
          const relT = t - start;
          const env = Math.exp(-relT * 10);
          sample += Math.sin(2 * Math.PI * f * relT) * env * 0.35;
        }
      });
      return sample;
    }));

    // 11. Game Over Sound: Descending sad arpeggio
    this.bufferCache.set('gameover', createBuffer(0.65, (t) => {
      const notes = [440, 415.3, 392, 349.23, 329.63, 261.63];
      let sample = 0;
      notes.forEach((f, idx) => {
        const start = idx * 0.09;
        if (t >= start) {
          const relT = t - start;
          const env = Math.exp(-relT * 8);
          sample += Math.sin(2 * Math.PI * f * relT) * env * 0.3;
        }
      });
      return sample;
    }));
  }

  // Play pre-cached AudioBuffer with instantaneous zero-lag start
  private playBuffer(key: string, gainMultiplier: number = 1.0) {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx || !this.sfxGainNode) return;

    const buffer = this.bufferCache.get(key);
    if (!buffer) return;

    try {
      const source = this.ctx.createBufferSource();
      source.buffer = buffer;

      if (gainMultiplier !== 1.0) {
        const tempGain = this.ctx.createGain();
        tempGain.gain.setValueAtTime(gainMultiplier * this.soundVolume, this.ctx.currentTime);
        source.connect(tempGain);
        tempGain.connect(this.ctx.destination);
      } else {
        source.connect(this.sfxGainNode);
      }

      source.start(0);
    } catch (_) {}
  }

  public setSoundVolume(vol: number) {
    this.soundVolume = Math.max(0, Math.min(1, vol));
    if (this.sfxGainNode && this.ctx) {
      this.sfxGainNode.gain.setValueAtTime(this.soundVolume, this.ctx.currentTime);
    }
  }

  public setMusicVolume(vol: number) {
    this.musicVolume = Math.max(0, Math.min(1, vol));
    if (this.musicGainNode && this.ctx) {
      this.musicGainNode.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  public isMusicOn(): boolean {
    return this.musicEnabled;
  }

  public playMove() {
    this.playBuffer('move');
  }

  public playRotate() {
    this.playBuffer('rotate');
  }

  public playRotate180() {
    this.playBuffer('rotate180');
  }

  public playSoftDrop() {
    const nowMs = performance.now();
    if (nowMs - this.lastSoftDropTime < 35) return;
    this.lastSoftDropTime = nowMs;
    this.playBuffer('softDrop');
  }

  public playHardDrop() {
    this.playBuffer('hardDrop');
  }

  public playLock() {
    this.playBuffer('lock');
  }

  public playHold() {
    this.playBuffer('hold');
  }

  public playLineClear(lines: number) {
    const clamped = Math.max(1, Math.min(4, lines));
    this.playBuffer(`clear_${clamped}`);
  }

  public playTSpin() {
    this.playBuffer('tspin');
  }

  public playCombo(comboCount: number) {
    const mult = Math.min(1.5, 1.0 + comboCount * 0.05);
    this.playBuffer('move', mult);
  }

  public playLevelUp() {
    this.playBuffer('levelup');
  }

  public playGameOver() {
    this.playBuffer('gameover');
  }

  private startMusic() {
    if (this.isMusicPlaying) return;
    this.initContext();
    if (!this.ctx) return;
    this.isMusicPlaying = true;
    this.musicGainNode = this.ctx.createGain();
    this.musicGainNode.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
    this.musicGainNode.connect(this.ctx.destination);

    // Korobeiniki Melody
    const E5 = 659.25;
    const B4 = 493.88;
    const C5 = 523.25;
    const D5 = 587.33;
    const A4 = 440.0;
    const G4 = 392.0;
    const F5 = 698.46;

    const melody: [number, number][] = [
      [E5, 4], [B4, 2], [C5, 2], [D5, 4], [C5, 2], [B4, 2],
      [A4, 4], [A4, 2], [C5, 2], [E5, 4], [D5, 2], [C5, 2],
      [B4, 6], [C5, 2], [D5, 4], [E5, 4],
      [C5, 4], [A4, 4], [A4, 6], [0, 2],
      [D5, 4], [F5, 2], [A4 * 2, 4], [G4 * 2, 2], [F5, 2],
      [E5, 6], [C5, 2], [E5, 4], [D5, 2], [C5, 2],
      [B4, 4], [B4, 2], [C5, 2], [D5, 4], [E5, 4],
      [C5, 4], [A4, 4], [A4, 6], [0, 2],
    ];

    let noteIdx = 0;
    const stepDurationMs = 135;

    const playNext = () => {
      if (!this.isMusicPlaying || !this.ctx || !this.musicEnabled) return;
      const [freq, sixteenths] = melody[noteIdx];
      const durationSec = (sixteenths * stepDurationMs) / 1000;

      if (freq > 0) {
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        noteGain.gain.setValueAtTime(0.08, this.ctx.currentTime);
        noteGain.gain.exponentialRampToValueAtTime(
          0.001,
          this.ctx.currentTime + durationSec * 0.95
        );
        osc.connect(noteGain);
        noteGain.connect(this.musicGainNode!);
        osc.start();
        osc.stop(this.ctx.currentTime + durationSec);
      }

      noteIdx = (noteIdx + 1) % melody.length;
      this.musicInterval = setTimeout(playNext, sixteenths * stepDurationMs);
    };

    playNext();
  }

  private stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearTimeout(this.musicInterval);
      this.musicInterval = null;
    }
  }
}

export const soundManager = new SoundManager();
