import { useState, useEffect, useRef, useMemo } from 'react';
import { useTetris, DEFAULT_SETTINGS } from './hooks/useTetris.ts';
import type { GameMode, GameSettings } from './game/types.ts';
import { getFallSpeed } from './game/rules.ts';
import { getPaletteColors } from './game/constants.ts';
import { TRANSLATIONS } from './game/i18n.ts';
import { TetrisBoard } from './components/TetrisBoard.tsx';
import { HoldQueue } from './components/HoldQueue.tsx';
import { NextQueue } from './components/NextQueue.tsx';
import { StatsPanel } from './components/StatsPanel.tsx';
import { VirtualControls } from './components/VirtualControls.tsx';
import { PauseMenuModal } from './components/PauseMenuModal.tsx';
import { GameOverModal } from './components/GameOverModal.tsx';
import { ModeSelectModal } from './components/ModeSelectModal.tsx';
import { Pause } from 'lucide-react';

export default function App() {
  const [showPauseMenu, setShowPauseMenu] = useState(false);
  const [showInitialModeSelect, setShowInitialModeSelect] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return false;
    }
    return true;
  });
  // Guideline 2.3.3/6: Marathon starting level (1-15, default 1)
  const [startLevel, setStartLevel] = useState(1);

  const initialMode: GameMode = (() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const m = params.get('mode');
      if (m === 'sprint' || m === 'ultra' || m === 'freeplay') return m;
    }
    return 'marathon';
  })();

  const {
    mode,
    setMode,
    board,
    activePiece,
    ghostY,
    holdPiece,
    canHold,
    nextQueue,
    stats,
    isPaused,
    isGameOver,
    isWon,
    settings,
    setSettings,
    actionBanners,
    levelBanner,
    clearingRows,
    hardDropTrail,
    hardDropImpact,
    matrixShake,
    lockFlash,
    startNewGame,
    moveLeft,
    moveRight,
    softDrop,
    hardDrop,
    rotateCW,
    rotateCCW,
    rotate180,
    hold,
    togglePause,
    resetWallBump,
    debugSetBoard,
  } = useTetris(initialMode);

  // Load, sync and save settings
  useEffect(() => {
    try {
      // One-time palette migration: the old default was Monochrome. The new
      // default is the solid multi-color palette; a deliberate later choice
      // of Monochrome is preserved.
      const paletteMigrationKey = 'tetris_palette_solid_v1';
      const needsPaletteMigration = !localStorage.getItem(paletteMigrationKey);

      // v2 key: guideline-default refresh (music on, guideline DAS/ARR timings)
      const saved = localStorage.getItem('tetris_settings_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.ghostOpacity !== undefined && parsed.ghostOpacity > 0.50) {
          parsed.ghostOpacity = 0.50;
        }
        if (parsed.colorPalette === 'cyberpunk') {
          parsed.colorPalette = 'vivid_guideline';
        }
        if (needsPaletteMigration && parsed.colorPalette === 'monochrome_gray') {
          parsed.colorPalette = 'vivid_guideline';
        }
        // Legacy block skin values (connected/separated) map to the solid skin.
        if (parsed.blockSkin !== 'solid' && parsed.blockSkin !== 'lines') {
          parsed.blockSkin = 'solid';
        }
        const merged = { ...DEFAULT_SETTINGS, ...parsed };
        setSettings(merged);
        // Persist the merged object so new defaults (and the one-time palette
        // migration) stick across reloads, including in the standalone build.
        localStorage.setItem('tetris_settings_v2', JSON.stringify(merged));
        fetch('/api/save-defaults', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(merged),
        }).catch(() => {});
      }

      if (needsPaletteMigration) {
        localStorage.setItem(paletteMigrationKey, '1');
      }
    } catch (_) {}
  }, [setSettings]);

  const handleUpdateSettings = (newPartial: Partial<GameSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newPartial };
      try {
        localStorage.setItem('tetris_settings_v2', JSON.stringify(updated));
        fetch('/api/save-defaults', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updated),
        }).catch(() => {});
      } catch (_) {}
      return updated;
    });
  };

  const handleOpenPause = () => {
    if (!isPaused) {
      togglePause();
    }
    setShowPauseMenu(true);
  };

  const handleResume = () => {
    setShowPauseMenu(false);
    if (isPaused) {
      togglePause();
    }
  };

  const handleSelectMode = (newMode: GameMode, level: number = 1) => {
    setMode(newMode);
    setStartLevel(level);
    startNewGame(newMode, level);
    setShowPauseMenu(false);
  };

  const handleRestartFromMenu = () => {
    startNewGame(mode, startLevel);
    setShowPauseMenu(false);
  };

  // Keyboard controls with precision DAS & ARR that never drop inputs
  const controlsRef = useRef({
    moveLeft,
    moveRight,
    softDrop,
    hardDrop,
    rotateCW,
    rotateCCW,
    rotate180,
    hold,
    togglePause,
    resetWallBump,
    startNewGame,
    mode,
    startLevel,
    level: stats.level,
    settings,
    showPauseMenu,
    handleResume,
    handleOpenPause,
  });

  useEffect(() => {
    controlsRef.current = {
      moveLeft,
      moveRight,
      softDrop,
      hardDrop,
      rotateCW,
      rotateCCW,
      rotate180,
      hold,
      togglePause,
      resetWallBump,
      startNewGame,
      mode,
      startLevel,
      level: stats.level,
      settings,
      showPauseMenu,
      handleResume,
      handleOpenPause,
    };
    (window as any).__tetris = {
      getBoard: () => board,
      getActivePiece: () => activePiece,
      getStats: () => stats,
      getClearingRows: () => clearingRows,
      hardDrop,
      moveLeft,
      moveRight,
      rotateCW,
      rotateCCW,
      rotate180,
      hold,
      startNewGame,
      debugSetBoard,
      updateSettings: handleUpdateSettings,
    };
  });

  const keyState = useRef<{
    activeDirection: 'left' | 'right' | null;
    dasTimer: any;
    arrTimer: any;
    softDropTimer: any;
    heldKeys: Set<string>;
  }>({
    activeDirection: null,
    dasTimer: null,
    arrTimer: null,
    softDropTimer: null,
    heldKeys: new Set(),
  });

  const stopDirectionTimers = () => {
    if (keyState.current.dasTimer) {
      clearTimeout(keyState.current.dasTimer);
      keyState.current.dasTimer = null;
    }
    if (keyState.current.arrTimer) {
      clearInterval(keyState.current.arrTimer);
      keyState.current.arrTimer = null;
    }
    keyState.current.activeDirection = null;
  };

  const startKeyboardRepeat = (dir: 'left' | 'right', immediate: boolean = true) => {
    const prevDirection = keyState.current.activeDirection;
    stopDirectionTimers();
    keyState.current.activeDirection = dir;
    const action = dir === 'left' ? controlsRef.current.moveLeft : controlsRef.current.moveRight;

    // Guideline 5.2: a fresh tap moves immediately; changing direction while holding
    // waits the initial DAS delay before the first auto-repeat step.
    if (immediate && prevDirection === null) {
      action();
    }

    const das = Math.max(30, controlsRef.current.settings.das || 300);
    keyState.current.dasTimer = setTimeout(() => {
      action();
      const arr = Math.max(0, controlsRef.current.settings.arr);
      if (arr === 0) {
        for (let i = 0; i < 10; i++) {
          action();
        }
      } else {
        keyState.current.arrTimer = setInterval(() => {
          action();
        }, arr);
      }
    }, das);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      const code = e.code;
      if (keyState.current.heldKeys.has(code)) {
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(code)) {
          e.preventDefault();
        }
        return;
      }
      keyState.current.heldKeys.add(code);

      switch (code) {
        case 'ArrowLeft':
        case 'Numpad4':
          e.preventDefault();
          startKeyboardRepeat('left');
          break;
        case 'ArrowRight':
        case 'Numpad6':
          e.preventDefault();
          startKeyboardRepeat('right');
          break;
        case 'ArrowDown':
        case 'Numpad2':
          e.preventDefault();
          controlsRef.current.softDrop();
          if (!keyState.current.softDropTimer) {
            // Guideline 5.5: Soft Drop runs at 20x (user-set SDF) the current
            // fall speed. The interval is recomputed on every tick so level
            // changes apply immediately; no artificial floor below 1ms.
            const scheduleSoftDrop = () => {
              const currentSpeed = getFallSpeed(controlsRef.current.level, controlsRef.current.mode);
              const dropInterval = Math.max(
                1,
                Math.floor(currentSpeed / (controlsRef.current.settings.sdf || 20))
              );
              keyState.current.softDropTimer = setTimeout(() => {
                controlsRef.current.softDrop();
                scheduleSoftDrop();
              }, dropInterval);
            };
            scheduleSoftDrop();
          }
          break;
        case 'Space':
        case 'Numpad8':
          e.preventDefault();
          controlsRef.current.hardDrop();
          break;
        case 'ArrowUp':
        case 'KeyX':
        case 'Numpad1':
        case 'Numpad5':
        case 'Numpad9':
          e.preventDefault();
          controlsRef.current.rotateCW();
          break;
        case 'KeyZ':
        case 'ControlLeft':
        case 'ControlRight':
        case 'Numpad3':
        case 'Numpad7':
          e.preventDefault();
          controlsRef.current.rotateCCW();
          break;
        case 'KeyA':
        case 'KeyQ':
          e.preventDefault();
          controlsRef.current.rotate180();
          break;
        case 'KeyC':
        case 'ShiftLeft':
        case 'ShiftRight':
        case 'Numpad0':
          e.preventDefault();
          controlsRef.current.hold();
          break;
        case 'Escape':
        case 'KeyP':
        case 'F1':
          e.preventDefault();
          if (controlsRef.current.showPauseMenu) {
            controlsRef.current.handleResume();
          } else {
            controlsRef.current.handleOpenPause();
          }
          break;
        case 'KeyR':
          e.preventDefault();
          controlsRef.current.startNewGame(controlsRef.current.mode, controlsRef.current.startLevel);
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      keyState.current.heldKeys.delete(code);

      if (code === 'ArrowLeft' || code === 'Numpad4') {
        controlsRef.current.resetWallBump();
        if (keyState.current.activeDirection === 'left') {
          stopDirectionTimers();
          if (
            keyState.current.heldKeys.has('ArrowRight') ||
            keyState.current.heldKeys.has('Numpad6')
          ) {
            startKeyboardRepeat('right', false);
          }
        }
      }
      if (code === 'ArrowRight' || code === 'Numpad6') {
        controlsRef.current.resetWallBump();
        if (keyState.current.activeDirection === 'right') {
          stopDirectionTimers();
          if (
            keyState.current.heldKeys.has('ArrowLeft') ||
            keyState.current.heldKeys.has('Numpad4')
          ) {
            startKeyboardRepeat('left', false);
          }
        }
      }
      if (code === 'ArrowDown' || code === 'Numpad2') {
        if (keyState.current.softDropTimer) {
          clearTimeout(keyState.current.softDropTimer);
          keyState.current.softDropTimer = null;
        }
      }
    };

    const handleBlur = () => {
      keyState.current.heldKeys.clear();
      controlsRef.current.resetWallBump();
      stopDirectionTimers();
      if (keyState.current.softDropTimer) {
        clearTimeout(keyState.current.softDropTimer);
        keyState.current.softDropTimer = null;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
      stopDirectionTimers();
      if (keyState.current.softDropTimer) {
        clearTimeout(keyState.current.softDropTimer);
      }
    };
  }, []);

  const handleStartFromSelect = (chosenMode: GameMode, chosenLevel: number = 1) => {
    setMode(chosenMode);
    setStartLevel(chosenLevel);
    startNewGame(chosenMode, chosenLevel);
    setShowInitialModeSelect(false);
  };

  const lang = settings.language || 'en';
  const t = TRANSLATIONS[lang];

  const currentPalette = useMemo(
    () => getPaletteColors(settings.colorPalette, settings.monochromeColor),
    [settings.colorPalette, settings.monochromeColor]
  );
  const activePieceDef = activePiece ? currentPalette[activePiece.type] : null;
  const activePieceColor = activePieceDef?.solid || '#38bdf8';
  const activePieceGlow = activePieceDef?.glow || 'rgba(56, 189, 248, 0.6)';

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col justify-between items-center py-2 px-2 select-none overflow-x-hidden font-sans">
      {/* Top Header Bar: Clean Mode badge on left, Pause on right */}
      <header className="w-full max-w-[460px] flex items-center justify-between px-2 pt-1 pb-1 flex-shrink-0">
        <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50 text-zinc-300 uppercase font-medium tracking-wider">
          {t.modes[mode].name}
        </span>
        <button
          type="button"
          aria-label={t.pause}
          onClick={handleOpenPause}
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-md bg-zinc-800/60 hover:bg-zinc-700/60 active:bg-zinc-600/60 border border-zinc-700/50 text-zinc-300 hover:text-white flex items-center justify-center transition-all active:scale-95 cursor-pointer"
        >
          <Pause className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current" />
        </button>
      </header>

      {/* Main Playfield Area */}
      <main className="flex-1 flex flex-col items-center justify-center w-full max-w-[480px] my-auto">
        {/* 3-Column Playfield Row: Left (Hold & Stats), Center (Board), Right (Next) */}
        <div className="flex items-start justify-center gap-2 sm:gap-3 w-full max-w-[460px]">
          {/* Left Column: HOLD on top + STATS below */}
          <div
            className="flex flex-col items-center flex-shrink-0 w-14 sm:w-16"
            style={{ paddingTop: 'calc(28px + 1.5 * clamp(20px, 4.8vh, 25px))' }}
          >
            <HoldQueue
              piece={holdPiece}
              canHold={canHold}
              colorPalette={settings.colorPalette}
              monochromeColor={settings.monochromeColor}
              blockSkin={settings.blockSkin}
            />
            <StatsPanel stats={stats} mode={mode} language={lang} />
          </div>

          {/* Center Column: Action Splashes on top, Tetris Matrix directly below */}
          <div className="flex flex-col items-center flex-shrink-0">
            {/* Header row for splash action banners directly ABOVE the glass: Action on LEFT, Level Up in CENTER, Combo on RIGHT */}
            <div
              className="h-8 sm:h-9 mb-1.5 flex items-center justify-between pointer-events-none overflow-visible relative flex-shrink-0 px-0.5"
              style={{ width: 'clamp(200px, 48vh, 250px)' }}
            >
              {/* Left Side: TETRIS, T-SPIN, DOUBLE, TRIPLE, PERFECT CLEAR */}
              <div className="flex-1 flex items-center justify-start pointer-events-none overflow-visible pr-1">
                {settings.actionTextEnabled !== false &&
                  actionBanners.map((banner) =>
                    banner.text ? (
                      <span
                        key={`action-${banner.id}`}
                        className="font-mono font-black text-xs sm:text-[13px] tracking-wider uppercase animate-splash-pop-left text-left whitespace-nowrap leading-none"
                        style={{
                          color: banner.color || '#ffffff',
                          textShadow: `0 0 8px ${banner.color || '#ffffff'}90, 0 0 16px ${banner.color || '#ffffff'}40`,
                        }}
                      >
                        {banner.text}
                      </span>
                    ) : null
                  )}
              </div>

              {/* Center: Dedicated LEVEL UP splash - separated so it never collides with action banners */}
              <div className="flex items-center justify-center pointer-events-none overflow-visible px-1">
                {settings.actionTextEnabled !== false && levelBanner && (
                  <span
                    key={`level-${levelBanner.id}`}
                    className="font-mono font-black text-xs sm:text-[13px] tracking-widest uppercase text-amber-300 animate-bounce whitespace-nowrap leading-none"
                    style={{
                      textShadow: '0 0 8px rgba(251, 191, 36, 0.9), 0 0 16px rgba(251, 191, 36, 0.5)',
                    }}
                  >
                    LEVEL {levelBanner.level}!
                  </span>
                )}
              </div>

              {/* Right Side: Combo Banner */}
              <div className="flex-1 flex items-center justify-end pointer-events-none overflow-visible pl-1">
                {settings.actionTextEnabled !== false &&
                  actionBanners.map((banner) =>
                    banner.subText ? (
                      <span
                        key={`combo-${banner.id}`}
                        className="font-mono font-black text-xs sm:text-[13px] tracking-wider uppercase text-amber-300 animate-splash-pop-right text-right whitespace-nowrap leading-none"
                        style={{
                          textShadow: '0 0 8px rgba(252, 211, 77, 0.9), 0 0 16px rgba(252, 211, 77, 0.5)',
                        }}
                      >
                        {banner.subText}
                      </span>
                    ) : null
                  )}
              </div>
            </div>

            <TetrisBoard
              board={board}
              activePiece={activePiece}
              ghostY={ghostY}
              clearingRows={clearingRows}
              showGhost={settings.ghostPiece}
              ghostColor={settings.ghostColor}
              ghostOpacity={settings.ghostOpacity}
              gridOpacity={settings.gridOpacity}
              ghostOutline={settings.ghostOutline}
              showWhiteOutline={settings.showWhiteOutline}
              whiteOutlineOpacity={settings.whiteOutlineOpacity}
              softPieceGlow={settings.softPieceGlow}
              matrixShakeEnabled={settings.matrixShakeEnabled}
              impactParticlesEnabled={settings.impactParticlesEnabled}
              lockFlashEnabled={settings.lockFlashEnabled}
              lineClearEffectsEnabled={settings.lineClearEffectsEnabled}
              gridStyle={settings.gridStyle}
              colorPalette={settings.colorPalette}
              monochromeColor={settings.monochromeColor}
              blockSkin={settings.blockSkin}
              ghostStyle={settings.ghostStyle}
              hardDropTrail={hardDropTrail}
              hardDropImpact={hardDropImpact}
              matrixShake={matrixShake}
              lockFlash={lockFlash}
              isPaused={isPaused}
            />
          </div>

          {/* Right Column: NEXT queue */}
          <div
            className="flex flex-col items-center flex-shrink-0 w-14 sm:w-16"
            style={{ paddingTop: 'calc(28px + 1.5 * clamp(20px, 4.8vh, 25px))' }}
          >
            <NextQueue
              queue={nextQueue}
              count={5}
              colorPalette={settings.colorPalette}
              monochromeColor={settings.monochromeColor}
              blockSkin={settings.blockSkin}
            />
          </div>
        </div>

        {/* Bottom Virtual Controls with true multi-touch and zero latency */}
        <VirtualControls
          onMoveLeft={moveLeft}
          onMoveRight={moveRight}
          onSoftDrop={softDrop}
          onHardDrop={hardDrop}
          onRotateCW={rotateCW}
          onRotateCCW={rotateCCW}
          onRotate180={rotate180}
          onHold={hold}
          onResetWallBump={resetWallBump}
          settings={settings}
          activeColor={activePieceColor}
          activeGlow={activePieceGlow}
          softGlowEnabled={settings.softPieceGlow !== false}
        />

        {/* Invisible bottom spacer to lift matrix and controls higher up on the screen */}
        <div className="h-16 sm:h-24 md:h-28 w-full flex-shrink-0 pointer-events-none" />
      </main>
      {/* Additional bottom viewport lift spacer */}
      <div className="h-6 sm:h-10 w-full flex-shrink-0 pointer-events-none" aria-hidden="true" />

      {/* Mode Select Start Screen on first launch */}
      <ModeSelectModal
        isOpen={showInitialModeSelect}
        selectedMode={mode}
        language={lang}
        onSelectAndStart={handleStartFromSelect}
      />

      {/* Submenus */}
      <PauseMenuModal
        isOpen={showPauseMenu}
        onResume={handleResume}
        onRestart={handleRestartFromMenu}
        mode={mode}
        onSelectMode={handleSelectMode}
        startLevel={startLevel}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      <GameOverModal
        isGameOver={isGameOver}
        isWon={isWon}
        stats={stats}
        mode={mode}
        language={lang}
        onRestart={() => startNewGame(mode, startLevel)}
      />
    </div>
  );
}
