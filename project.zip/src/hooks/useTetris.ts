import { useState, useEffect, useCallback, useRef } from 'react';
import { useAudio } from '../utils/audio';
import { getSRSShift } from '../game/srs';
import { SHAPES, COLORS, BOARD_WIDTH, BOARD_HEIGHT } from '../game/constants';
import { TetrominoShape } from '../game/types';

export const useTetris = (initialSettings: any) => {
  const [board, setBoard] = useState<string[][]>(
    Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(''))
  );
  const [currentPiece, setCurrentPiece] = useState({
    shape: 'I' as TetrominoShape,
    matrix: SHAPES['I'],
    color: COLORS['I'],
    x: 3,
    y: 0,
    rotation: 0
  });
  const [nextQueue, setNextQueue] = useState<TetrominoShape[]>(['T', 'O', 'J', 'L']);
  const [holdPiece, setHoldPiece] = useState<TetrominoShape | null>(null);
  const [canHold, setCanHold] = useState(true);
  const [score, setScore] = useState(0);
  const [lines, setLines] = useState(0);
  const [level, setLevel] = useState(1);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const audio = useAudio();

  const requestRef = useRef<number | null>(null);
  const stateRef = useRef({
    board: Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill('')),
    currentPiece: { shape: 'I' as TetrominoShape, matrix: SHAPES['I'], color: COLORS['I'], x: 3, y: 0, rotation: 0 },
    gravityFrames: 53, 
    frameCount: 0,
    lockDelayFrames: 30,
    lockDelayCounter: 0,
    isLocking: false,
    lockMoveResets: 0,
    score: 0,
    lines: 0,
    level: 1,
    isGameOver: false,
    isPaused: false
  });

  useEffect(() => {
    stateRef.current.currentPiece = currentPiece;
    stateRef.current.board = board;
    stateRef.current.score = score;
    stateRef.current.lines = lines;
    stateRef.current.level = level;
    stateRef.current.isGameOver = isGameOver;
    stateRef.current.isPaused = isPaused;
  }, [currentPiece, board, score, lines, level, isGameOver, isPaused]);

  const generateBag = () => {
    const bag: TetrominoShape[] = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
    for (let i = bag.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [bag[i], bag[j]] = [bag[j], bag[i]];
    }
    return bag;
  };

  const checkCollision = (matrix: number[][], ax: number, ay: number, currentBoard: string[][]) => {
    for (let r = 0; r < matrix.length; r++) {
      for (let c = 0; c < matrix[r].length; c++) {
        if (matrix[r][c]) {
          const nextX = ax + c;
          const nextY = ay + r;
          if (nextX < 0 || nextX >= BOARD_WIDTH || nextY >= BOARD_HEIGHT) return true;
          if (nextY >= 0 && currentBoard[nextY][nextX] !== '') return true;
        }
      }
    }
    return false;
  };

  const checkTSpin = (x: number, y: number, currentBoard: string[][]) => {
    if (stateRef.current.currentPiece.shape !== 'T') return false;
    let corners = 0;
    const cornerPositions = [
      { dx: 0, dy: 0 }, { dx: 2, dy: 0 },
      { dx: 0, dy: 2 }, { dx: 2, dy: 2 }
    ];
    cornerPositions.forEach(pos => {
      const cx = x + pos.dx;
      const cy = y + pos.dy;
      if (cx < 0 || cx >= BOARD_WIDTH || cy >= BOARD_HEIGHT || (cy >= 0 && currentBoard[cy][cx] !== '')) {
        corners++;
      }
    });
    return corners >= 3;
  };

  const gameLoop = () => {
    const state = stateRef.current;

    if (!state.isGameOver && !state.isPaused) {
      const isOnGround = checkCollision(state.currentPiece.matrix, state.currentPiece.x, state.currentPiece.y + 1, state.board);
      
      if (isOnGround) {
        if (!state.isLocking) {
          state.isLocking = true;
          state.lockDelayCounter = 0;
        }
        state.lockDelayCounter++;
        
        if (state.lockDelayCounter >= state.lockDelayFrames) {
          lockPiece();
          state.isLocking = false;
        }
      } else {
        state.isLocking = false;
        state.lockDelayCounter = 0;
        state.frameCount++;
        
        if (state.frameCount >= state.gravityFrames) {
          state.frameCount = 0;
          movePiece(0, 1);
        }
      }
    }
    requestRef.current = requestAnimationFrame(gameLoop);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(gameLoop);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const movePiece = useCallback((dx: number, dy: number) => {
    const state = stateRef.current;
    if (state.isGameOver || state.isPaused) return false;

    if (!checkCollision(state.currentPiece.matrix, state.currentPiece.x + dx, state.currentPiece.y + dy, state.board)) {
      setCurrentPiece(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
      if (state.isLocking && state.lockMoveResets < 15) {
        state.lockDelayCounter = 0;
        state.lockMoveResets++;
      }
      return true;
    }
    return false;
  }, []);

  const rotatePiece = useCallback(() => {
    const state = stateRef.current;
    if (state.isGameOver || state.isPaused) return;

    const nextRotation = (state.currentPiece.rotation + 1) % 4;
    const nextMatrix = SHAPES[state.currentPiece.shape][nextRotation];
    const shifts = getSRSShift(state.currentPiece.shape, state.currentPiece.rotation, nextRotation);
    
    for (let i = 0; i < shifts.length; i++) {
      const [shiftX, shiftY] = shifts[i];
      if (!checkCollision(nextMatrix, state.currentPiece.x + shiftX, state.currentPiece.y - shiftY, state.board)) {
        
        const isTSpin = checkTSpin(state.currentPiece.x + shiftX, state.currentPiece.y - shiftY, state.board);
        if (isTSpin) {
          audio.play('tspin');
          setScore(prev => prev + 400 * state.level);
        } else {
          audio.play('rotate');
        }

        setCurrentPiece(prev => ({
          ...prev,
          matrix: nextMatrix,
          rotation: nextRotation,
          x: prev.x + shiftX,
          y: prev.y - shiftY
        }));

        if (state.isLocking && state.lockMoveResets < 15) {
          state.lockDelayCounter = 0;
          state.lockMoveResets++;
        }
        break;
      }
    }
  }, [audio]);

  const lockPiece = useCallback(() => {
    const state = stateRef.current;
    const newBoard = state.board.map(row => [...row]);
    
    state.currentPiece.matrix.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (cell) {
          const boardY = state.currentPiece.y + r;
          const boardX = state.currentPiece.x + c;
          if (boardY >= 0 && boardY < BOARD_HEIGHT) {
            newBoard[boardY][boardX] = state.currentPiece.color;
          }
        }
      });
    });

    let clearedLines = 0;
    const filteredBoard = newBoard.filter(row => {
      const isFull = row.every(cell => cell !== '');
      if (isFull) clearedLines++;
      return !isFull;
    });

    while (filteredBoard.length < BOARD_HEIGHT) {
      filteredBoard.unshift(Array(BOARD_WIDTH).fill(''));
    }

    if (clearedLines > 0) {
      const linePoints: Record<number, number> = { 1: 100, 2: 300, 3: 500, 4: 800 };
      setScore(prev => prev + (linePoints[clearedLines] || 0) * state.level);
      setLines(prev => prev + clearedLines);
      audio.play(clearedLines === 4 ? 'tetris' : 'clear');
      
      const nextLevel = Math.floor((state.lines + clearedLines) / 10) + 1;
      if (nextLevel > state.level) {
        setLevel(nextLevel);
        stateRef.current.gravityFrames = Math.max(4, 53 - nextLevel * 4);
      }
    } else {
      audio.play('lock');
    }

    const nextShape = nextQueue[0];
    const updatedQueue = [...nextQueue.slice(1)];
    if (updatedQueue.length < 4) updatedQueue.push(...generateBag());
    setNextQueue(updatedQueue);

    state.lockMoveResets = 0;
    const spawnPiece = {
      shape: nextShape,
      matrix: SHAPES[nextShape][0],
      color: COLORS[nextShape],
      x: 3,
      y: 0,
      rotation: 0
    };

    if (checkCollision(spawnPiece.matrix, spawnPiece.x, spawnPiece.y, filteredBoard)) {
      setIsGameOver(true);
      audio.play('gameover');
    } else {
      setCurrentPiece(spawnPiece);
      setCanHold(true);
    }

    setBoard(filteredBoard);
  }, [nextQueue, audio]);

  const hardDrop = useCallback(() => {
    const state = stateRef.current;
    if (state.isGameOver || state.isPaused) return;

    let dropDist = 0;
    while (!checkCollision(state.currentPiece.matrix, state.currentPiece.x, state.currentPiece.y + dropDist + 1, state.board)) {
      dropDist++;
    }

    setScore(prev => prev + dropDist * 2);
    setCurrentPiece(prev => ({ ...prev, y: prev.y + dropDist }));
    audio.play('harddrop');
    lockPiece();
  }, [lockPiece, audio]);

  const hold = useCallback(() => {
    const state = stateRef.current;
    if (state.isGameOver || state.isPaused || !canHold) return;

    audio.play('hold');
    const currentShape = state.currentPiece.shape;

    if (holdPiece === null) {
      const nextShape = nextQueue[0];
      const updatedQueue = [...nextQueue.slice(1)];
      if (updatedQueue.length < 4) updatedQueue.push(...generateBag());
      setNextQueue(updatedQueue);
      
      setHoldPiece(currentShape);
      setCurrentPiece({
        shape: nextShape,
        matrix: SHAPES[nextShape][0],
        color: COLORS[nextShape],
        x: 3,
        y: 0,
        rotation: 0
      });
    } else {
      const prevHold = holdPiece;
      setHoldPiece(currentShape);
      setCurrentPiece({
        shape: prevHold,
        matrix: SHAPES[prevHold][0],
        color: COLORS[prevHold],
        x: 3,
        y: 0,
        rotation: 0
      });
    }
    setCanHold(false);
  }, [holdPiece, nextQueue, canHold, audio]);

  return {
    board,
    currentPiece,
    nextQueue,
    holdPiece,
    score,
    lines,
    level,
    isGameOver,
    isPaused,
    movePiece,
    rotatePiece,
    hardDrop,
    hold,
    setIsPaused
  };
};
