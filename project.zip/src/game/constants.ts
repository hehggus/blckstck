import type { PieceType, RotationState, ColorPalette } from './types.ts';

export const MATRIX_WIDTH = 10;
export const MATRIX_TOTAL_HEIGHT = 40; // 0..19 buffer, 20..39 visible
export const MATRIX_VISIBLE_HEIGHT = 20;
export const VISIBLE_START_ROW = 20;

export interface PieceColorDef {
  gradient: string;
  border: string;
  glow: string;
  solid: string;
  neonGlass: string;
  neonInner: string;
}

// 1. Pastel Neon Palette (Modern, luminous yet refined neon hues)
export const PASTEL_NEON_PALETTE: Record<PieceType, PieceColorDef> = {
  I: {
    gradient: 'linear-gradient(180deg, #6eeeff 0%, #29c8e8 100%)',
    border: '#20b6d4',
    glow: 'rgba(56, 232, 255, 0.6)',
    solid: '#3fe3ff',
    neonGlass: 'rgba(63, 227, 255, 0.35)',
    neonInner: 'rgba(150, 245, 255, 0.85)',
  },
  J: {
    gradient: 'linear-gradient(180deg, #7daaff 0%, #4679f2 100%)',
    border: '#3b66d4',
    glow: 'rgba(110, 160, 255, 0.6)',
    solid: '#5c8eff',
    neonGlass: 'rgba(92, 142, 255, 0.35)',
    neonInner: 'rgba(175, 205, 255, 0.85)',
  },
  L: {
    gradient: 'linear-gradient(180deg, #ffb877 0%, #fa7f28 100%)',
    border: '#d96716',
    glow: 'rgba(255, 165, 95, 0.6)',
    solid: '#ff9a48',
    neonGlass: 'rgba(255, 154, 72, 0.35)',
    neonInner: 'rgba(255, 215, 175, 0.85)',
  },
  O: {
    gradient: 'linear-gradient(180deg, #fff37a 0%, #ffd024 100%)',
    border: '#d4a511',
    glow: 'rgba(255, 235, 75, 0.6)',
    solid: '#ffe635',
    neonGlass: 'rgba(255, 230, 53, 0.35)',
    neonInner: 'rgba(255, 250, 175, 0.85)',
  },
  S: {
    gradient: 'linear-gradient(180deg, #7ff4af 0%, #2bd46f 100%)',
    border: '#20b85a',
    glow: 'rgba(90, 235, 145, 0.6)',
    solid: '#4ae888',
    neonGlass: 'rgba(74, 232, 136, 0.35)',
    neonInner: 'rgba(175, 255, 205, 0.85)',
  },
  T: {
    gradient: 'linear-gradient(180deg, #e3a2ff 0%, #a448f2 100%)',
    border: '#8f33dc',
    glow: 'rgba(215, 135, 255, 0.6)',
    solid: '#c86bfa',
    neonGlass: 'rgba(200, 107, 250, 0.35)',
    neonInner: 'rgba(240, 195, 255, 0.85)',
  },
  Z: {
    gradient: 'linear-gradient(180deg, #ff8299 0%, #f43f63 100%)',
    border: '#d12448',
    glow: 'rgba(255, 105, 135, 0.6)',
    solid: '#ff5c7d',
    neonGlass: 'rgba(255, 92, 125, 0.35)',
    neonInner: 'rgba(255, 185, 200, 0.85)',
  },
};

// 2. Vivid Guideline Palette (Authentic saturated arcade standard)
export const VIVID_GUIDELINE_PALETTE: Record<PieceType, PieceColorDef> = {
  I: {
    gradient: 'linear-gradient(180deg, #00f0f0 0%, #009999 100%)',
    border: '#008080',
    glow: 'rgba(0, 240, 240, 0.7)',
    solid: '#00dcdc',
    neonGlass: 'rgba(0, 240, 240, 0.35)',
    neonInner: 'rgba(180, 255, 255, 0.9)',
  },
  J: {
    gradient: 'linear-gradient(180deg, #2b5cff 0%, #0a2eb8 100%)',
    border: '#062085',
    glow: 'rgba(43, 92, 255, 0.7)',
    solid: '#1a4ee8',
    neonGlass: 'rgba(43, 92, 255, 0.35)',
    neonInner: 'rgba(160, 190, 255, 0.9)',
  },
  L: {
    gradient: 'linear-gradient(180deg, #ff7a00 0%, #b84700 100%)',
    border: '#8f3700',
    glow: 'rgba(255, 122, 0, 0.7)',
    solid: '#ff7300',
    neonGlass: 'rgba(255, 122, 0, 0.35)',
    neonInner: 'rgba(255, 205, 140, 0.9)',
  },
  O: {
    gradient: 'linear-gradient(180deg, #ffd700 0%, #b89600 100%)',
    border: '#8f7500',
    glow: 'rgba(255, 215, 0, 0.7)',
    solid: '#facc15',
    neonGlass: 'rgba(255, 215, 0, 0.35)',
    neonInner: 'rgba(255, 245, 140, 0.9)',
  },
  S: {
    gradient: 'linear-gradient(180deg, #00e639 0%, #008f23 100%)',
    border: '#00701c',
    glow: 'rgba(0, 230, 57, 0.7)',
    solid: '#00d634',
    neonGlass: 'rgba(0, 230, 57, 0.35)',
    neonInner: 'rgba(160, 255, 180, 0.9)',
  },
  T: {
    gradient: 'linear-gradient(180deg, #b829ea 0%, #6e0f91 100%)',
    border: '#560b73',
    glow: 'rgba(184, 41, 234, 0.7)',
    solid: '#a81ce0',
    neonGlass: 'rgba(184, 41, 234, 0.35)',
    neonInner: 'rgba(235, 160, 255, 0.9)',
  },
  Z: {
    gradient: 'linear-gradient(180deg, #ff2442 0%, #b80d24 100%)',
    border: '#8f0a1c',
    glow: 'rgba(255, 36, 66, 0.7)',
    solid: '#f41b39',
    neonGlass: 'rgba(255, 36, 66, 0.35)',
    neonInner: 'rgba(255, 160, 175, 0.9)',
  },
};

// Color manipulation helpers for dynamic monochrome palette
function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  if (clean.length === 3) {
    const r = parseInt(clean[0] + clean[0], 16);
    const g = parseInt(clean[1] + clean[1], 16);
    const b = parseInt(clean[2] + clean[2], 16);
    return [r, g, b];
  }
  const r = parseInt(clean.substring(0, 2), 16) || 148;
  const g = parseInt(clean.substring(2, 4), 16) || 163;
  const b = parseInt(clean.substring(4, 6), 16) || 184;
  return [r, g, b];
}

export function hexToRgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function adjustColor(hex: string, percent: number): string {
  const [r, g, b] = hexToRgb(hex);
  const clamp = (val: number) => Math.min(255, Math.max(0, Math.round(val)));
  const factor = 1 + percent / 100;
  const newR = clamp(r * factor);
  const newG = clamp(g * factor);
  const newB = clamp(b * factor);
  const toHex = (n: number) => n.toString(16).padStart(2, '0');
  return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
}

// Unified Monochrome Palette Generator: ALL 7 pieces share the exact SAME color
export function createMonochromePalette(baseHex: string = '#94a3b8'): Record<PieceType, PieceColorDef> {
  const pieceDef: PieceColorDef = {
    gradient: `linear-gradient(180deg, ${adjustColor(baseHex, 20)} 0%, ${adjustColor(baseHex, -20)} 100%)`,
    border: adjustColor(baseHex, -35),
    glow: hexToRgba(baseHex, 0.65),
    solid: baseHex,
    neonGlass: hexToRgba(baseHex, 0.35),
    neonInner: hexToRgba(adjustColor(baseHex, 35), 0.85),
  };
  return {
    I: pieceDef,
    J: pieceDef,
    L: pieceDef,
    O: pieceDef,
    S: pieceDef,
    T: pieceDef,
    Z: pieceDef,
  };
}

export const MONOCHROME_GRAY_PALETTE: Record<PieceType, PieceColorDef> = createMonochromePalette('#94a3b8');

export const GHOST_GRAY_COLOR = '#a1a1aa';

export const COLOR_PALETTES: Record<ColorPalette, Record<PieceType, PieceColorDef>> = {
  pastel_neon: PASTEL_NEON_PALETTE,
  vivid_guideline: VIVID_GUIDELINE_PALETTE,
  monochrome_gray: MONOCHROME_GRAY_PALETTE,
};

export function getPaletteColors(
  palette: ColorPalette,
  monochromeColor: string = '#94a3b8'
): Record<PieceType, PieceColorDef> {
  if (palette === 'monochrome_gray') {
    return createMonochromePalette(monochromeColor);
  }
  return COLOR_PALETTES[palette] || COLOR_PALETTES.vivid_guideline;
}

// Grayscale definition for unavailable Hold piece
export const GRAYSCALE_COLORS: PieceColorDef = {
  gradient: 'linear-gradient(180deg, #8a92a3 0%, #454b57 100%)',
  border: '#333842',
  glow: 'rgba(120, 130, 150, 0.2)',
  solid: '#5a6275',
  neonGlass: 'rgba(90, 98, 117, 0.3)',
  neonInner: 'rgba(190, 195, 205, 0.7)',
};

export const PIECE_NAMES: Record<PieceType, string> = {
  I: 'I-Tetrimino',
  J: 'J-Tetrimino',
  L: 'L-Tetrimino',
  O: 'O-Tetrimino',
  S: 'S-Tetrimino',
  T: 'T-Tetrimino',
  Z: 'Z-Tetrimino',
};

// Shape matrices for all 4 rotation states: [row][col]
export const PIECE_SHAPES: Record<PieceType, Record<RotationState, number[][]>> = {
  I: {
    0: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ],
    1: [
      [0, 0, 1, 0],
      [0, 0, 1, 0],
      [0, 0, 1, 0],
      [0, 0, 1, 0],
    ],
    2: [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
    ],
    3: [
      [0, 1, 0, 0],
      [0, 1, 0, 0],
      [0, 1, 0, 0],
      [0, 1, 0, 0],
    ],
  },
  J: {
    0: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
    1: [
      [0, 1, 1],
      [0, 1, 0],
      [0, 1, 0],
    ],
    2: [
      [0, 0, 0],
      [1, 1, 1],
      [0, 0, 1],
    ],
    3: [
      [0, 1, 0],
      [0, 1, 0],
      [1, 1, 0],
    ],
  },
  L: {
    0: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0],
    ],
    1: [
      [0, 1, 0],
      [0, 1, 0],
      [0, 1, 1],
    ],
    2: [
      [0, 0, 0],
      [1, 1, 1],
      [1, 0, 0],
    ],
    3: [
      [1, 1, 0],
      [0, 1, 0],
      [0, 1, 0],
    ],
  },
  O: {
    0: [
      [1, 1],
      [1, 1],
    ],
    1: [
      [1, 1],
      [1, 1],
    ],
    2: [
      [1, 1],
      [1, 1],
    ],
    3: [
      [1, 1],
      [1, 1],
    ],
  },
  S: {
    0: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0],
    ],
    1: [
      [0, 1, 0],
      [0, 1, 1],
      [0, 0, 1],
    ],
    2: [
      [0, 0, 0],
      [0, 1, 1],
      [1, 1, 0],
    ],
    3: [
      [1, 0, 0],
      [1, 1, 0],
      [0, 1, 0],
    ],
  },
  T: {
    0: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
    1: [
      [0, 1, 0],
      [0, 1, 1],
      [0, 1, 0],
    ],
    2: [
      [0, 0, 0],
      [1, 1, 1],
      [0, 1, 0],
    ],
    3: [
      [0, 1, 0],
      [1, 1, 0],
      [0, 1, 0],
    ],
  },
  Z: {
    0: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0],
    ],
    1: [
      [0, 0, 1],
      [0, 1, 1],
      [0, 1, 0],
    ],
    2: [
      [0, 0, 0],
      [1, 1, 0],
      [0, 1, 1],
    ],
    3: [
      [0, 1, 0],
      [1, 1, 0],
      [1, 0, 0],
    ],
  },
};

// Spawn coordinates in 40-high board (Guideline section 3.4 & A1.2.1)
// Row 21st in 1-based indexing from bottom corresponds to buffer row y: 18
// Then immediately drops 1 row to y: 19 if unobstructed, placing base on visible row 20
export const SPAWN_COORDINATES: Record<PieceType, { x: number; y: number }> = {
  I: { x: 3, y: 18 },
  J: { x: 3, y: 18 },
  L: { x: 3, y: 18 },
  O: { x: 4, y: 18 },
  S: { x: 3, y: 18 },
  T: { x: 3, y: 18 },
  Z: { x: 3, y: 18 },
};

// Guideline Fall Speeds (page 20 of 2009 Guideline PDF)
export const LEVEL_FALL_SPEEDS_MS: Record<number, number> = {
  1: 1000,
  2: 793,
  3: 618,
  4: 473,
  5: 355,
  6: 262,
  7: 190,
  8: 135,
  9: 94,
  10: 64,
  11: 43,
  12: 28,
  13: 18,
  14: 11,
  15: 7,
};

export const LOCK_DELAY_MS = 500;
export const MAX_LOCK_MOVES = 15;
