import type { Language, GameMode, ColorPalette, GridStyle, GhostStyle, GhostColor, BlockSkin } from './types.ts';

export interface TranslationStrings {
  // Common / Header
  pause: string;
  resume: string;
  restart: string;
  paused: string;
  pausePrompt: string;
  on: string;
  off: string;
  settings: string;
  close: string;
  
  // Game Modes
  modes: Record<GameMode, { name: string; desc: string }>;
  chooseMode: string;
  startGame: string;
  highScores: string;
  noHighScores: string;
  playAgain: string;
  victory: string;
  gameOver: string;
  
  // Stats
  score: string;
  level: string;
  lines: string;
  time: string;
  hold: string;
  next: string;
  pieces: string;
  maxCombo: string;
  tetrises: string;
  tspins: string;
  b2b: string;
  
  // Pause Menu Tabs
  tabMode: string;
  tabHandling: string;
  tabAudio: string;
  
  // Settings - Visuals
  visualEffects: string;
  boardBlocks: string;
  guidesOutlines: string;
  language: string;
  palette: string;
  palettes: Record<ColorPalette, string>;
  blockSkin: string;
  blockSkins: Record<BlockSkin, string>;
  monochromeColor: string;
  ghostOpacity: string;
  gridOpacity: string;
  ghostOutline: string;
  ghostPiece: string;
  ghostStyle: string;
  ghostStyles: Record<GhostStyle, string>;
  ghostColor: string;
  ghostColors: Record<GhostColor, string>;
  whiteOutline: string;
  whiteOutlineOpacity: string;
  softPieceGlow: string;
  matrixShake: string;
  impactParticles: string;
  lockFlash: string;
  lineClearFx: string;
  actionText: string;
  gridStyle: string;
  gridStyles: Record<GridStyle, string>;
  
  // Settings - Handling
  das: string;
  dasDesc: string;
  arr: string;
  arrDesc: string;
  sdf: string;
  sdfDesc: string;
  
  // Settings - Audio
  soundFx: string;
  soundVol: string;
  music: string;
  musicVol: string;
  
  // Presets
  monochromeColors: Record<string, string>;

  // Save Defaults & Export
  saveAsDefault: string;
  savedAsDefault: string;
  saveDefaultDesc: string;
  downloadSource: string;
  downloadSourceDesc: string;
}

export const TRANSLATIONS: Record<Language, TranslationStrings> = {
  en: {
    pause: 'Pause',
    resume: 'Resume',
    restart: 'Restart',
    paused: 'PAUSED',
    pausePrompt: 'Press Pause to Resume',
    on: 'On',
    off: 'Off',
    settings: 'Settings',
    close: 'Close',
    
    modes: {
      marathon: { name: 'Marathon', desc: '15 levels of play' },
      sprint: { name: 'Sprint 40L', desc: 'Clear 40 lines fast' },
      ultra: { name: 'Ultra 2 min', desc: '2 min score attack' },
      freeplay: { name: 'Freeplay', desc: 'Endless casual practice' },
    },
    chooseMode: 'CHOOSE GAME MODE',
    startGame: 'START GAME',
    highScores: 'HIGH SCORES',
    noHighScores: 'NO RECORDS YET',
    playAgain: 'PLAY AGAIN',
    victory: 'VICTORY!',
    gameOver: 'GAME OVER',
    
    score: 'SCORE',
    level: 'LEVEL',
    lines: 'LINES',
    time: 'TIME',
    hold: 'HOLD',
    next: 'NEXT',
    pieces: 'Pieces',
    maxCombo: 'Max Combo',
    tetrises: 'Tetrises',
    tspins: 'T-Spins',
    b2b: 'Back-to-Back',
    
    tabMode: 'Mode',
    tabHandling: 'Handling',
    tabAudio: 'Audio',
    
    language: 'Language',
    visualEffects: 'Visual Effects',
    boardBlocks: 'Board & Blocks',
    guidesOutlines: 'Guides & Outlines',
    palette: 'Color Palette',
    palettes: {
      pastel_neon: 'Pastel Neon',
      vivid_guideline: 'Vivid Classic',
      monochrome_gray: 'Monochrome',
    },
    blockSkin: 'Block Skin',
    blockSkins: {
      solid: 'Solid',
      lines: 'Black Lines',
    },
    monochromeColor: 'Monochrome Color',
    ghostOpacity: 'Ghost Opacity',
    gridOpacity: 'Grid Opacity',
    ghostOutline: 'Ghost Outline',
    ghostPiece: 'Ghost Piece',
    ghostStyle: 'Ghost Style',
    ghostStyles: {
      solid: 'Connected',
      separated: 'Blocks',
    },
    ghostColor: 'Ghost Color',
    ghostColors: {
      colored: 'Colored',
      gray: 'Gray',
    },
    whiteOutline: 'White Active Outline',
    whiteOutlineOpacity: 'Outline Opacity',
    softPieceGlow: 'Soft Glow',
    matrixShake: 'Screen Shake',
    impactParticles: 'Impact FX',
    lockFlash: 'Lock Flash',
    lineClearFx: 'Line Clear FX',
    actionText: 'Action Text',
    gridStyle: 'Field Grid Style',
    gridStyles: {
      checkerboard: 'Checkerboard',
      grid: 'Grid Lines',
    },
    
    das: 'Delayed Auto Shift (DAS)',
    dasDesc: 'Delay before auto-repeat begins (ms)',
    arr: 'Auto Repeat Rate (ARR)',
    arrDesc: 'Interval between repeat shifts (ms)',
    sdf: 'Soft Drop Factor (SDF)',
    sdfDesc: 'Soft drop speed multiplier',
    
    soundFx: 'Sound Effects',
    soundVol: 'Sound Volume',
    music: 'Music',
    musicVol: 'Music Volume',
    
    monochromeColors: {
      '#94a3b8': 'Light Gray',
      '#38bdf8': 'Cyan',
      '#60a5fa': 'Blue',
      '#c084fc': 'Purple',
      '#f472b6': 'Pink',
      '#f87171': 'Red',
      '#fb923c': 'Orange',
      '#facc15': 'Yellow',
      '#4ade80': 'Green',
      '#2dd4bf': 'Mint',
      '#f8fafc': 'White',
    },
    saveAsDefault: 'Set as Default Settings',
    savedAsDefault: 'Saved as Default!',
    saveDefaultDesc: 'Current settings will become the defaults',
    downloadSource: 'Download Source Code (.zip)',
    downloadSourceDesc: 'Clean game logic, SRS tables, sounds & components',
  },
};

export const MONOCHROME_PRESETS: Array<{ hex: string; enName: string }> = [
  { hex: '#94a3b8', enName: 'Light Gray' },
  { hex: '#38bdf8', enName: 'Cyan' },
  { hex: '#60a5fa', enName: 'Blue' },
  { hex: '#c084fc', enName: 'Purple' },
  { hex: '#f472b6', enName: 'Pink' },
  { hex: '#f87171', enName: 'Red' },
  { hex: '#fb923c', enName: 'Orange' },
  { hex: '#facc15', enName: 'Yellow' },
  { hex: '#4ade80', enName: 'Green' },
  { hex: '#2dd4bf', enName: 'Mint' },
  { hex: '#f8fafc', enName: 'White' },
];
