import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createEmptyBoard,
  generate7Bag,
  spawnPiece,
  checkCollision,
  tryMovePiece,
  tryRotatePiece,
  getGhostPieceY,
  detectTSpin,
  checkAndClearLines,
  calculateScoring,
  getFallSpeed,
  getMarathonLevel,
  getMarathonTargetLines,
  formatTime,
} from './rules.ts';
import { getSRSKicks } from './srs.ts';
import { SPAWN_COORDINATES, LEVEL_FALL_SPEEDS_MS } from './constants.ts';

test('createEmptyBoard initializes 40x10 matrix', () => {
  const board = createEmptyBoard();
  assert.equal(board.length, 40);
  assert.equal(board[0].length, 10);
  assert.equal(board.every((row) => row.every((c) => c === null)), true);
});

test('7-Bag generator: distribution across multiple bags', () => {
  // Test 20 bags (140 pieces)
  for (let b = 0; b < 20; b++) {
    const bag = generate7Bag();
    assert.equal(bag.length, 7);
    const sorted = [...bag].sort().join('');
    assert.equal(sorted, 'IJLOSTZ', 'Each bag must contain exactly one of each of the 7 pieces');
  }
});

test('Starting location and orientation (Guideline Section 3.4 & A1.2.1)', () => {
  const board = createEmptyBoard();
  // Spawns on row 21 (buffer row y: 18)
  for (const type of ['I', 'J', 'L', 'O', 'S', 'T', 'Z'] as const) {
    const piece = spawnPiece(type);
    assert.equal(piece.y, 18, `${type} must spawn at y: 18 (row 21 in 1-based indexing)`);
    assert.equal(piece.rotation, 0, `${type} must spawn North facing`);
    assert.equal(checkCollision(board, piece.type, piece.rotation, piece.x, piece.y), false);

    // Dropping 1 row down puts center at row 20 (top visible row)
    const drop = tryMovePiece(board, piece, 0, 1);
    assert.equal(drop.success, true);
    assert.equal(drop.piece.y, 19);
  }
});

test('Boundary and floor collision checks', () => {
  const board = createEmptyBoard();
  const piece = spawnPiece('T');
  assert.equal(checkCollision(board, piece.type, piece.rotation, piece.x, piece.y), false);

  // Out of left bound
  assert.equal(checkCollision(board, piece.type, piece.rotation, -2, piece.y), true);
  // Out of right bound
  assert.equal(checkCollision(board, piece.type, piece.rotation, 9, piece.y), true);
  // Floor collision (row 40)
  assert.equal(checkCollision(board, piece.type, piece.rotation, piece.x, 39), true);
});

test('Extended Placement lock down: counter resets on descent to lower row (Guideline Section 5.7)', () => {
  const board = createEmptyBoard();
  let piece = spawnPiece('T');
  piece.lowestY = piece.y;
  piece.lockMovesCount = 0;

  // Horizontal move at same height increments counter
  const move1 = tryMovePiece(board, piece, 1, 0);
  assert.equal(move1.piece.lockMovesCount, 1);

  // Another horizontal move increments counter
  const move2 = tryMovePiece(board, move1.piece, -1, 0);
  assert.equal(move2.piece.lockMovesCount, 2);

  // Moving down past lowestY resets counter to 0!
  const moveDown = tryMovePiece(board, move2.piece, 0, 1);
  assert.equal(moveDown.success, true);
  assert.equal(moveDown.piece.lockMovesCount, 0, 'Counter must reset when piece descends below lowest row yet reached');
  assert.equal(moveDown.piece.lowestY, piece.y + 1);
});

test('SRS rotation CW, CCW, and 180° with kick tables', () => {
  const board = createEmptyBoard();
  const piece = spawnPiece('T');

  const rotateCW = tryRotatePiece(board, piece, 'CW');
  assert.equal(rotateCW.success, true);
  assert.equal(rotateCW.piece.rotation, 1);
  assert.equal(rotateCW.kickIndex, 0);

  const rotateCCW = tryRotatePiece(board, piece, 'CCW');
  assert.equal(rotateCCW.success, true);
  assert.equal(rotateCCW.piece.rotation, 3);
  assert.equal(rotateCCW.kickIndex, 0);

  const rotate180 = tryRotatePiece(board, piece, '180');
  assert.equal(rotate180.success, true);
  assert.equal(rotate180.piece.rotation, 2);

  // Verify O piece has exactly 1 kick test point [0, 0]
  const oKicks = getSRSKicks('O', 0, 1);
  assert.deepEqual(oKicks, [[0, 0]]);

  // Verify I piece kick table exists for all 4 states
  assert.equal(getSRSKicks('I', 0, 1).length, 5);
  assert.equal(getSRSKicks('I', 1, 2).length, 5);
  assert.equal(getSRSKicks('I', 2, 3).length, 5);
  assert.equal(getSRSKicks('I', 3, 0).length, 5);
});

test('Guideline Fall Speeds (Section 7, page 20)', () => {
  assert.equal(getFallSpeed(1, 'marathon'), 1000);
  assert.equal(getFallSpeed(2, 'marathon'), 793);
  assert.equal(getFallSpeed(3, 'marathon'), 618);
  assert.equal(getFallSpeed(4, 'marathon'), 473);
  assert.equal(getFallSpeed(5, 'marathon'), 355);
  assert.equal(getFallSpeed(6, 'marathon'), 262);
  assert.equal(getFallSpeed(7, 'marathon'), 190);
  assert.equal(getFallSpeed(8, 'marathon'), 135);
  assert.equal(getFallSpeed(9, 'marathon'), 94);
  assert.equal(getFallSpeed(10, 'marathon'), 64);
  assert.equal(getFallSpeed(11, 'marathon'), 43);
  assert.equal(getFallSpeed(12, 'marathon'), 28);
  assert.equal(getFallSpeed(13, 'marathon'), 18);
  assert.equal(getFallSpeed(14, 'marathon'), 11);
  assert.equal(getFallSpeed(15, 'marathon'), 7);

  // Freeplay should remain at relaxed 1000ms
  assert.equal(getFallSpeed(10, 'freeplay'), 1000);
});

test('Line clear detection and scoring table (Guideline Section 8, page 21)', () => {
  const board = createEmptyBoard();
  // Fill the bottom 2 rows completely
  for (let c = 0; c < 10; c++) {
    board[38][c] = 'I';
    board[39][c] = 'I';
  }

  const { newBoard, clearedRowIndices, isAllClear } = checkAndClearLines(board);
  assert.equal(clearedRowIndices.length, 2);
  assert.equal(isAllClear, true);

  // Guideline Section 8 Scoring:
  // Single: 100 * Level
  assert.equal(calculateScoring(1, 'none', false, 0, false, 1).points, 100);
  assert.equal(calculateScoring(1, 'none', false, 0, false, 3).points, 300);

  // Double: 300 * Level
  assert.equal(calculateScoring(2, 'none', false, 0, false, 1).points, 300);
  assert.equal(calculateScoring(2, 'none', false, 0, false, 4).points, 1200);

  // Triple: 500 * Level
  assert.equal(calculateScoring(3, 'none', false, 0, false, 1).points, 500);

  // Tetris: 800 * Level
  assert.equal(calculateScoring(4, 'none', false, 0, false, 1).points, 800);
  assert.equal(calculateScoring(4, 'none', false, 0, false, 2).points, 1600);

  // Tetris with B2B bonus (+50%): 800 * 1.5 * Level = 1200
  const tetrisB2B = calculateScoring(4, 'none', true, 0, false, 1);
  assert.equal(tetrisB2B.points, 1200);
  assert.equal(tetrisB2B.actionText, 'B2B TETRIS!');
});

test('Line clear and collapse: rows above fall down by exact cleared count (Guideline A1.2.7)', () => {
  const board = createEmptyBoard();
  // Fill row 39 completely
  for (let c = 0; c < 10; c++) {
    board[39][c] = 'I';
  }
  // Put a single block in row 38 at col 4
  board[38][4] = 'T';

  const { newBoard, clearedRowIndices, isAllClear } = checkAndClearLines(board);
  assert.equal(clearedRowIndices.length, 1);
  assert.equal(clearedRowIndices[0], 39);
  assert.equal(isAllClear, false);

  // The 'T' that was at row 38 should now have collapsed down to row 39 at col 4!
  assert.equal(newBoard[39][4], 'T');
  // Row 38 should now be empty at col 4
  assert.equal(newBoard[38][4], null);
});

test('T-Spin and Mini T-Spin scoring (Guideline Section 8, page 21)', () => {
  // Mini T-Spin (0 lines): 100 * level
  assert.equal(calculateScoring(0, 'mini', false, 0, false, 1).points, 100);
  // Mini T-Spin Single: 200 * level
  assert.equal(calculateScoring(1, 'mini', false, 0, false, 1).points, 200);
  // Mini T-Spin Single with B2B: 200 * 1.5 * level = 300
  assert.equal(calculateScoring(1, 'mini', true, 0, false, 1).points, 300);

  // Regular T-Spin (0 lines): 400 * level
  assert.equal(calculateScoring(0, 'regular', false, 0, false, 1).points, 400);
  // T-Spin Single: 800 * level
  assert.equal(calculateScoring(1, 'regular', false, 0, false, 1).points, 800);
  // T-Spin Single B2B: 800 * 1.5 = 1200
  assert.equal(calculateScoring(1, 'regular', true, 0, false, 1).points, 1200);

  // T-Spin Double: 1200 * level
  assert.equal(calculateScoring(2, 'regular', false, 0, false, 1).points, 1200);
  // T-Spin Double B2B: 1200 * 1.5 = 1800
  assert.equal(calculateScoring(2, 'regular', true, 0, false, 1).points, 1800);

  // T-Spin Triple: 1600 * level
  assert.equal(calculateScoring(3, 'regular', false, 0, false, 1).points, 1600);
  // T-Spin Triple B2B: 1600 * 1.5 = 2400
  assert.equal(calculateScoring(3, 'regular', true, 0, false, 1).points, 2400);
});

test('T-Spin detection and Point 5 lock upgrade (Guideline 9.1.1 & 9.1.2)', () => {
  const board = createEmptyBoard();
  const piece = {
    type: 'T' as const,
    rotation: 0 as const,
    x: 4,
    y: 36,
    lowestY: 36,
    lockMovesCount: 0,
  };

  // 2 rear corners + 1 front corner without Point 5 kick = Mini T-Spin
  board[38][4] = 'I'; // SW (rear)
  board[38][6] = 'I'; // SE (rear)
  board[36][4] = 'I'; // NW (front)

  const tSpinMini = detectTSpin(board, piece, true, 0);
  assert.equal(tSpinMini, 'mini');

  // Same configuration but with Point 5 kick = Regular T-Spin
  const tSpinPoint5 = detectTSpin(board, piece, true, 4, false);
  assert.equal(tSpinPoint5, 'regular');

  // If piece has hasUsedPoint5Kick = true, even kickIndex 0 upgrades to regular
  const pieceWithPoint5 = { ...piece, hasUsedPoint5Kick: true };
  const tSpinLockedUpgrade = detectTSpin(board, pieceWithPoint5, true, 0, false);
  assert.equal(tSpinLockedUpgrade, 'regular');
});

test('Back-to-Back sequence example verification (Guideline Section 8.1, page 21)', () => {
  // Guideline 8.1:
  // Sequence at Level 1:
  // 1. Tetris: 800 (starts B2B, no bonus)
  // 2. T-Spin Double: 1200 + 600 (B2B bonus) = 1800
  // 3. T-Spin (0 lines): 400 (no B2B bonus, does not break B2B)
  // 4. Tetris: 800 + 400 (B2B bonus) = 1200
  // 5. T-Spin Single: 800 + 400 (B2B bonus) = 1200
  // Total: 800 + 1800 + 400 + 1200 + 1200 = 5400 points!

  let score = 0;
  let isB2BActive = false;

  // Step 1: Tetris
  const s1 = calculateScoring(4, 'none', isB2BActive, 0, false, 1);
  score += s1.points;
  if (s1.triggersB2B) isB2BActive = true;
  assert.equal(s1.points, 800);
  assert.equal(isB2BActive, true);

  // Step 2: T-Spin Double
  const s2 = calculateScoring(2, 'regular', isB2BActive, 0, false, 1);
  score += s2.points;
  if (s2.triggersB2B) isB2BActive = true;
  assert.equal(s2.points, 1800);
  assert.equal(isB2BActive, true);

  // Step 3: T-Spin (0 lines) - does not break B2B
  const s3 = calculateScoring(0, 'regular', isB2BActive, 0, false, 1);
  score += s3.points;
  assert.equal(s3.points, 400);
  assert.equal(isB2BActive, true);

  // Step 4: Tetris
  const s4 = calculateScoring(4, 'none', isB2BActive, 0, false, 1);
  score += s4.points;
  if (s4.triggersB2B) isB2BActive = true;
  assert.equal(s4.points, 1200);
  assert.equal(isB2BActive, true);

  // Step 5: T-Spin Single
  const s5 = calculateScoring(1, 'regular', isB2BActive, 0, false, 1);
  score += s5.points;
  if (s5.triggersB2B) isB2BActive = true;
  assert.equal(s5.points, 1200);
  assert.equal(isB2BActive, true);

  assert.equal(score, 5400, 'Total score must match exact Guideline 8.1 example of 5400 points');
});

test('formatTime properly formats milliseconds', () => {
  assert.equal(formatTime(6110), '00:06.11');
  assert.equal(formatTime(65430), '01:05.43');
});

test('T-Spin rejected if last action was translation/drop, even if 3 corners occupied (Guideline Rule)', () => {
  const board = createEmptyBoard();
  const piece = {
    type: 'T' as const,
    rotation: 0 as const,
    x: 4,
    y: 36,
    lowestY: 36,
    lockMovesCount: 0,
  };
  // 3 corners occupied
  board[38][4] = 'I';
  board[38][6] = 'I';
  board[36][4] = 'I';

  // If last action was NOT rotation, MUST return 'none'
  const result = detectTSpin(board, piece, false, 0);
  assert.equal(result, 'none', 'T-Spin must be rejected if last action was not rotation');
});

test('Horizontal movement or drop clears hasUsedPoint5Kick', () => {
  const board = createEmptyBoard();
  const piece = {
    type: 'T' as const,
    rotation: 0 as const,
    x: 4,
    y: 30,
    lowestY: 30,
    lockMovesCount: 0,
    hasUsedPoint5Kick: true,
  };

  // Moving horizontally clears it
  const movedHoriz = tryMovePiece(board, piece, 1, 0);
  assert.equal(movedHoriz.piece.hasUsedPoint5Kick, false);

  // Dropping clears it
  const movedDown = tryMovePiece(board, piece, 0, 1);
  assert.equal(movedDown.piece.hasUsedPoint5Kick, false);
});

test('hasUsedPoint5Kick stays sticky across further rotations (Guideline 9.1.1)', () => {
  const board = createEmptyBoard();
  const piece = {
    type: 'T' as const,
    rotation: 0 as const,
    x: 4,
    y: 30,
    lowestY: 30,
    lockMovesCount: 0,
    hasUsedPoint5Kick: true,
  };

  // Guideline 9.1.1: once Point 5 has been used, "any further rotation will be
  // considered a t-Spin, not a Mini" — so even a plain kick-free rotation must
  // NOT clear the flag (only translation does, see test above).
  const res = tryRotatePiece(board, piece, 'CW');
  assert.equal(res.success, true);
  assert.equal(
    res.piece.hasUsedPoint5Kick,
    true,
    'A kick-free rotation must preserve Point 5 eligibility'
  );

  // And again through a second rotation
  const res2 = tryRotatePiece(board, res.piece, 'CW');
  assert.equal(res2.success, true);
  assert.equal(res2.piece.hasUsedPoint5Kick, true);
});

test('Marathon level progression honors the starting level (Guideline Section 6)', () => {
  // Default start (level 1): 10 lines per level
  assert.equal(getMarathonLevel(0, 1), 1);
  assert.equal(getMarathonLevel(9, 1), 1);
  assert.equal(getMarathonLevel(10, 1), 2);
  assert.equal(getMarathonLevel(140, 1), 15);
  assert.equal(getMarathonLevel(999, 1), 15, 'Level is capped at 15');

  // Starting from level 10
  assert.equal(getMarathonLevel(0, 10), 10);
  assert.equal(getMarathonLevel(10, 10), 11);
  assert.equal(getMarathonLevel(50, 10), 15);
  assert.equal(getMarathonLevel(999, 10), 15);

  // Starting from the final level: win after 10 lines
  assert.equal(getMarathonLevel(0, 15), 15);
  assert.equal(getMarathonLevel(999, 15), 15);
});

test('Marathon finish line offsets with the starting level (Guideline Section 6)', () => {
  assert.equal(getMarathonTargetLines(1), 150, 'Levels 1-15 = 150 lines');
  assert.equal(getMarathonTargetLines(5), 110, 'Levels 5-15 = 110 lines');
  assert.equal(getMarathonTargetLines(10), 60, 'Levels 10-15 = 60 lines');
  assert.equal(getMarathonTargetLines(15), 10, 'Level 15 alone = 10 lines');

  // Out-of-range inputs are clamped like getMarathonLevel
  assert.equal(getMarathonTargetLines(0), 150);
  assert.equal(getMarathonTargetLines(99), 10);
  assert.equal(getMarathonLevel(0, 0), 1);
  assert.equal(getMarathonLevel(0, 99), 15);
});

test('SRS kicks for 180° rotation work and are non-destructive', () => {
  const board = createEmptyBoard();
  for (const type of ['I', 'J', 'L', 'O', 'S', 'T', 'Z'] as const) {
    const piece = spawnPiece(type);
    const res180 = tryRotatePiece(board, piece, '180');
    assert.equal(res180.success, true);
    assert.equal(res180.piece.rotation, 2);
  }
});

