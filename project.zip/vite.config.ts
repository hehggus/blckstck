import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import path from 'path';
import fs from 'fs';
import { defineConfig, type Plugin } from 'vite';

function apiSettingsPlugin(): Plugin {
  return {
    name: 'api-settings',
    configureServer(server) {
      server.middlewares.use('/api/save-defaults', (req, res) => {
        if (req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });
          req.on('end', () => {
            try {
              const data = JSON.parse(body);
              const jsonPath = path.resolve(__dirname, 'src/game/current-settings.json');
              fs.writeFileSync(jsonPath, JSON.stringify(data, null, 2), 'utf8');

              // Update DEFAULT_SETTINGS in src/hooks/useTetris.ts
              const hookPath = path.resolve(__dirname, 'src/hooks/useTetris.ts');
              if (fs.existsSync(hookPath)) {
                let hookContent = fs.readFileSync(hookPath, 'utf8');
                const newDefaultSettingsStr = `export const DEFAULT_SETTINGS: GameSettings = {
  das: ${Number(data.das) || 133},
  arr: ${Number(data.arr) || 10},
  sdf: ${Number(data.sdf) || 20},
  ghostPiece: ${data.ghostPiece !== false},
  ghostStyle: ${JSON.stringify(data.ghostStyle || 'solid')},
  ghostColor: ${JSON.stringify(data.ghostColor || 'colored')},
  blockSkin: ${JSON.stringify(data.blockSkin || 'solid')},
  ghostOpacity: ${Number(data.ghostOpacity) || 0.05},
  gridOpacity: ${Number(data.gridOpacity) || 0.35},
  ghostOutline: ${data.ghostOutline !== false},
  soundVolume: ${Number(data.soundVolume) ?? 0.6},
  musicVolume: ${Number(data.musicVolume) ?? 0.3},
  soundEnabled: ${data.soundEnabled !== false},
  musicEnabled: ${data.musicEnabled === true},
  showWhiteOutline: ${data.showWhiteOutline !== false},
  whiteOutlineOpacity: ${Number(data.whiteOutlineOpacity ?? 1)},
  softPieceGlow: ${data.softPieceGlow !== false},
  matrixShakeEnabled: ${data.matrixShakeEnabled !== false},
  impactParticlesEnabled: ${data.impactParticlesEnabled !== false},
  lockFlashEnabled: ${data.lockFlashEnabled !== false},
  lineClearEffectsEnabled: ${data.lineClearEffectsEnabled !== false},
  actionTextEnabled: ${data.actionTextEnabled !== false},
  gridStyle: ${JSON.stringify(data.gridStyle || 'checkerboard')},
  colorPalette: ${JSON.stringify(data.colorPalette || 'vivid_guideline')},
  monochromeColor: ${JSON.stringify(data.monochromeColor || '#94a3b8')},
  language: ${JSON.stringify(data.language || 'en')},
};`;
                hookContent = hookContent.replace(
                  /export const DEFAULT_SETTINGS: GameSettings = \{[\s\S]*?\};/,
                  newDefaultSettingsStr
                );
                fs.writeFileSync(hookPath, hookContent, 'utf8');
              }

              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true, settings: data }));
            } catch (err: any) {
              res.statusCode = 500;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ error: err?.message || 'Error' }));
            }
          });
          return;
        }

        if (req.method === 'GET') {
          try {
            const jsonPath = path.resolve(__dirname, 'src/game/current-settings.json');
            if (fs.existsSync(jsonPath)) {
              const data = fs.readFileSync(jsonPath, 'utf8');
              res.setHeader('Content-Type', 'application/json');
              res.end(data);
              return;
            }
          } catch (_) {}
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({}));
          return;
        }

        res.statusCode = 404;
        res.end();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      viteSingleFile(),
      apiSettingsPlugin(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname || '.', '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
